#include "stdafx.h"
#include "RenderContainer.h"



//---------------------------dxobject---------------------------------
bool CRenderContainer::Begin() {

	return true;
}
bool CRenderContainer::End() {
	for (auto pObject : m_lpObjects) {
		pObject->End();
	}
	m_lpObjects.clear();

	//if (m_pMesh) m_pMesh->End();
	//if (m_pShader) m_pShader->End();
	//if (m_pTexture) m_pTexture->End();
	//if (m_pMaterial) m_pMaterial->End();
	//if (m_pBuffer) m_pBuffer->End();

	return true;
}
//---------------------------dxobject---------------------------------

//--------------------------container---------------------------------
void CRenderContainer::UpdateShaderState() {
	m_pMesh->UpdateShaderState();
	m_pShader->UpdateShaderState();
	if (m_pTexture) m_pTexture->UpdateShaderState();
	if (m_pMaterial) m_pMaterial->UpdateShaderState();
	if (m_pBuffer) m_pBuffer->UpdateShaderState();

	//----------------------------update instance buffer--------------------------

	if (!m_pBuffer) return;

	int nInstance = 0;
	//D3D11_MAPPED_SUBRESOURCE d3dMappedResource;
	//m_pd3dDeviceContext->Map(m_pd3dInstancingBuffer, 0, D3D11_MAP_WRITE_DISCARD, 0, &d3dMappedResource);
	void** ppData = m_pBuffer->Map();
	for (auto pObject : m_lpObjects) {
		pObject->SetInstanceBufferInfo(ppData, nInstance, m_pCamera);
		nInstance++;
	}

	m_nInstance = nInstance;
	/*for (int j = 0; j < nSphereObjects; j++)//camera culling code
	{
	if (m_ppObjects[j])
	{
	if (m_ppObjects[j]->IsVisible(pCamera))
	{
	D3DXMatrixTranspose(&pnSphereInstances[nSphereInstances].m_d3dxTransform, &m_ppObjects[j]->m_d3dxmtxWorld);
	pnSphereInstances[nSphereInstances++].m_d3dxColor = RANDOM_COLOR;
	}
	}
	}*/
	m_pBuffer->Unmap();
	//----------------------------update instance buffer--------------------------


}
void CRenderContainer::SetShaderState() {
	m_pMesh->SetShaderState();
	m_pShader->SetShaderState();
	if(m_pTexture) m_pTexture->SetShaderState();
	if(m_pMaterial) m_pMaterial->SetShaderState();
	if(m_pBuffer) m_pBuffer->SetShaderState();
	
}
void CRenderContainer::RenderExcute() {
	m_pMesh->RenderExcute(m_nInstance);
}
void CRenderContainer::RenderExcuteWithOutObject(){
	m_pMesh->RenderExcute(1);
}
void CRenderContainer::CleanShaderState() {
	m_pMesh->CleanShaderState();
	m_pShader->CleanShaderState();
	if(m_pTexture) m_pTexture->CleanShaderState();
	if(m_pBuffer) m_pBuffer->CleanShaderState();
	if(m_pMaterial) m_pMaterial->CleanShaderState();
	
}
//--------------------------container �Һ� �Լ�---------------------------------
void CRenderContainer::Render() {

	//shader State Update/ Instancing Buffet Update
	UpdateShaderState();

	SetShaderState();

	//Render!
	RenderExcute();

	CleanShaderState();

}

void CRenderContainer::RenderWithOutObject(){
	//shader State Update/ Instancing Buffet Update
	UpdateShaderState();

	SetShaderState();

	//Render!
	RenderExcuteWithOutObject();

	CleanShaderState();
}

void CRenderContainer::SetMesh(shared_ptr<CMesh> pMesh) {
	if (!pMesh) return;

	m_pMesh = pMesh;

}
void CRenderContainer::SetShader(shared_ptr<CRenderShader> pShader) {
	if (!pShader) return;

	m_pShader = pShader;

}
void CRenderContainer::SetTexture(shared_ptr<CTexture> pTexture) {
	if (!pTexture)return;

	m_pTexture = pTexture;
}
void CRenderContainer::SetBuffer(shared_ptr<CBuffer> pBuffer){
	if (!pBuffer) return;
	m_pBuffer = pBuffer;
}
void CRenderContainer::SetInstanceBuffer(shared_ptr<CBuffer> pBuffer){
	if (!pBuffer) return;
	m_pBuffer = pBuffer;
	m_pMesh->AssembleToVertexBuffer(m_pBuffer->GetnBuffers(), m_pBuffer->GetBuffers(), m_pBuffer->GetBufferStrides(), m_pBuffer->GetOffsets());
}
void CRenderContainer::SetMaterial(shared_ptr<CMaterial> pMaterial) {
	if (!pMaterial)return;

	m_pMaterial = pMaterial;
}

void CRenderContainer::SetObejcts(int n, CObject** ppObjects) {
	if (!ppObjects) return;

	for (int i = 0; i < n; ++i) {
		m_lpObjects.emplace_back(ppObjects[i]);
	}
}

void CRenderContainer::AddObject(CObject* pObject) {
	if (!pObject) return;

	m_lpObjects.emplace_back(pObject);
}
void CRenderContainer::RemoveObject(CObject* pObject) {
	if (!pObject) return;
	//if (0 == m_lpObjects.size()) return;

	m_lpObjects.remove_if([&pObject](CObject* pO) {
		return pObject == pO;
	});
}
//--------------------------container �Һ� �Լ�---------------------------------

CRenderContainer::CRenderContainer(shared_ptr<CCamera> pCamera, ID3D11Device* pd3dDevice, ID3D11DeviceContext* pd3dDeviceContext) : DXObject(pd3dDevice, pd3dDeviceContext) {
	m_pCamera = pCamera;
}
CRenderContainer::~CRenderContainer() {

}