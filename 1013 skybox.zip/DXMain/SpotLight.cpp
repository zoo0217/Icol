#include "stdafx.h"
#include "SpotLight.h"

bool CSpotLight::Begin(SPOT_LIGHT& light_info) {
	m_lightid = light_id::LIGHT_SPOT;
	m_objectID = object_id::OBJECT_SPOT_LIGHT;

	m_SpotData = light_info;

	//�̸� ��� ������ ���� ��� �� ���´�.
	float fCosInnerCone = cosf(XM_PI * m_SpotData.fInnerAngle / 180.0f);
	float fCosOuterCone = cosf(XM_PI * m_SpotData.fOuterAngle / 180.0f);
	float fSinOuterCone = sinf(XM_PI * m_SpotData.fOuterAngle / 180.0f);

	m_fSpotLightRangeRcp = 1.0 / m_SpotData.SpotLightRange;
	m_fSpotCosOuterCone = fCosOuterCone;
	m_fSpotSinOuterCone = fSinOuterCone;
	m_fSpotCosConeAttRcp = 1.0 / (fCosInnerCone - fCosOuterCone);

	float SpotLightRange = m_SpotData.SpotLightRange;
	m_xmmtxScale = XMMatrixScalingFromVector(XMVECTOR(XMLoadFloat4(&XMFLOAT4(SpotLightRange, SpotLightRange, SpotLightRange, 1.0))));


	//���ο� ��ü�� ���ܳ��� Begin���� Component���� set���ش�. 
	CComponent* pComponent = new CRotateComponent;
	pComponent->Begin();
	SetComponent(pComponent);

	return CLight::Begin();
}
bool CSpotLight::End() {

	return CLight::End();
}

//instance buffer controll base
void CSpotLight::SetInstanceBufferInfo(void** ppMappedResources, int& nInstance, shared_ptr<CCamera> pCamera) {

	//����ȯ
	SPOT_LIGHT_DS_CB *pDS_InstanceData = (SPOT_LIGHT_DS_CB*)ppMappedResources[0];
	SPOT_LIGHT_PS_CB *pPS_InstanceData = (SPOT_LIGHT_PS_CB*)ppMappedResources[1];
	//transpose ���� ���� ����
	
	//light projection �� �۾� gpu�� �Űܾ��� later
	XMMATRIX xmmtxWorld = GetWorldMtx();
	XMMATRIX xmmtxView = pCamera->GetViewMtx();
	XMMATRIX xmmtxProjection = pCamera->GetProjectionMtx();

	XMMATRIX xmmtxLight = m_xmmtxScale * xmmtxWorld * xmmtxView * xmmtxProjection;

	pDS_InstanceData[nInstance].LightProjection = XMMatrixTranspose(xmmtxLight);
	pDS_InstanceData[nInstance].SpotCosOuterCone = m_fSpotCosOuterCone;
	pDS_InstanceData[nInstance].SpotSinOuterCone = m_fSpotSinOuterCone;

	//light projection
	XMStoreFloat3(&pPS_InstanceData[nInstance].SpotLightPos, GetPosition());
	pPS_InstanceData[nInstance].SpotLightRangeRcp = m_fSpotLightRangeRcp;
	pPS_InstanceData[nInstance].SpotLightColor = m_SpotData.SpotLightColor;
	pPS_InstanceData[nInstance].SpotCosOuterCone  = m_fSpotCosOuterCone;
	pPS_InstanceData[nInstance].SpotCosConeAttRcp = m_fSpotCosConeAttRcp;
	XMStoreFloat3(&pPS_InstanceData[nInstance].SpotLightDir, -GetLook());

}

CSpotLight::CSpotLight() {
	
}
CSpotLight::~CSpotLight() {

}