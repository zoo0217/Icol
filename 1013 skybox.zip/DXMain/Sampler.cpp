#include "stdafx.h"
#include "Sampler.h"

bool CSampler::Begin(int nSamplers, UINT* pSlots, D3D11_TEXTURE_ADDRESS_MODE* pModes, D3D11_FILTER* pFilters, D3D11_COMPARISON_FUNC* pComparisionFuncs, float* pMinLODs, float* pMaxLODs, UINT* pBindFlags) {
	m_nSamplers = nSamplers;

	m_pSamplerStartSlots = new UINT[m_nSamplers];
	m_ppd3dSamplerState = new ID3D11SamplerState*[m_nSamplers];
	m_pBindFlags = new UINT[m_nSamplers];

	//set sampler state data
	D3D11_SAMPLER_DESC d3dSamplerDesc;
	for (int i = 0; i < m_nSamplers; ++i) {
		ZeroMemory(&d3dSamplerDesc, sizeof(D3D11_SAMPLER_DESC));
		m_pSamplerStartSlots[i] = pSlots[i];
		m_pBindFlags[i] = pBindFlags[i];

		//sampler
		d3dSamplerDesc.AddressU = pModes[i];
		d3dSamplerDesc.AddressV = pModes[i];
		d3dSamplerDesc.AddressW = pModes[i];

		d3dSamplerDesc.Filter = pFilters[i];
		d3dSamplerDesc.ComparisonFunc = pComparisionFuncs[i];
		d3dSamplerDesc.MinLOD = pMinLODs[i];
		d3dSamplerDesc.MaxLOD = pMaxLODs[i];

		m_pd3dDevice->CreateSamplerState(&d3dSamplerDesc, &m_ppd3dSamplerState[i]);
	}
	return true;
}
bool CSampler::End() {

	if (m_ppd3dSamplerState) {
		for (int i = 0; i < m_nSamplers; ++i)
			m_ppd3dSamplerState[i]->Release();
	}

	return true;
}

void CSampler::SetShaderState() {

	for (int i = 0; i < m_nSamplers; ++i) {
		if (m_pBindFlags[i] & BIND_VS) {
			m_pd3dDeviceContext->VSSetSamplers(m_pSamplerStartSlots[i], 1, &m_ppd3dSamplerState[i]);
		}
		if (m_pBindFlags[i] & BIND_DS) {
			m_pd3dDeviceContext->DSSetSamplers(m_pSamplerStartSlots[i], 1, &m_ppd3dSamplerState[i]);
		}
		if (m_pBindFlags[i] & BIND_HS) {
			m_pd3dDeviceContext->HSSetSamplers(m_pSamplerStartSlots[i], 1, &m_ppd3dSamplerState[i]);
		}
		if (m_pBindFlags[i] & BIND_GS) {
			m_pd3dDeviceContext->GSSetSamplers(m_pSamplerStartSlots[i], 1, &m_ppd3dSamplerState[i]);
		}
		if (m_pBindFlags[i] & BIND_PS) {
			m_pd3dDeviceContext->PSSetSamplers(m_pSamplerStartSlots[i], 1, &m_ppd3dSamplerState[i]);
		}
		if (m_pBindFlags[i] & BIND_CS) {
			m_pd3dDeviceContext->CSSetSamplers(m_pSamplerStartSlots[i], 1, &m_ppd3dSamplerState[i]);
		}
	}
	
}
void CSampler::CleanShaderState() {
	ID3D11SamplerState* pSamplerState[1] = { nullptr };

	for (int i = 0; i < m_nSamplers; ++i) {
		if (m_pBindFlags[i] & BIND_VS) {
			m_pd3dDeviceContext->VSSetSamplers(m_pSamplerStartSlots[i], 1, pSamplerState);
		}
		if (m_pBindFlags[i] & BIND_DS) {
			m_pd3dDeviceContext->DSSetSamplers(m_pSamplerStartSlots[i], 1, pSamplerState);
		}
		if (m_pBindFlags[i] & BIND_HS) {
			m_pd3dDeviceContext->HSSetSamplers(m_pSamplerStartSlots[i], 1, pSamplerState);
		}
		if (m_pBindFlags[i] & BIND_GS) {
			m_pd3dDeviceContext->GSSetSamplers(m_pSamplerStartSlots[i], 1, pSamplerState);
		}
		if (m_pBindFlags[i] & BIND_PS) {
			m_pd3dDeviceContext->PSSetSamplers(m_pSamplerStartSlots[i], 1, pSamplerState);
		}
		if (m_pBindFlags[i] & BIND_CS) {
			m_pd3dDeviceContext->CSSetSamplers(m_pSamplerStartSlots[i], 1, pSamplerState);
		}
	}

}

void CSampler::UpdateShaderState() {

}


CSampler::CSampler(ID3D11Device* pd3dDevice, ID3D11DeviceContext* pd3dDeviceContext) : DXObject(pd3dDevice, pd3dDeviceContext) { }
CSampler::~CSampler() { };

