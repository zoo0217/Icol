#include "stdafx.h"
#include "AnimateContainer.h"

//---------------------------dxobject---------------------------------
bool CAnimateContainer::Begin(CRenderContainerSeller* pSeller) {

	return true;
}
bool CAnimateContainer::End() {
	for (auto p = m_lpObjects.begin(); p != m_lpObjects.end(); ++p) {
		(*p)->End();
	}
	m_lpObjects.clear();
	return true;
}
//---------------------------dxobject---------------------------------

//--------------------------container---------------------------------

void CAnimateContainer::Animate(float fTimeElapsed, CAnimateContainer* pExcludeContainer) {
	//��� ��ü Animate
	for (auto p = m_lpObjects.begin(); p != m_lpObjects.end(); ++p) {
		(*p)->Animate(fTimeElapsed);
	}
}

//--------------------------container �Һ� �Լ�---------------------------------
void CAnimateContainer::SetObejcts(int n, CObject** ppObjects) {
	if (!ppObjects) return;

	for (int i = 0; i < n; ++i) {
		m_lpObjects.emplace_back(ppObjects[i]);
	}
}

void CAnimateContainer::AddObject(CObject* pObject) {
	if (!pObject) return;

	m_lpObjects.emplace_back(pObject);
}
void CAnimateContainer::RemoveObject(CObject* pObject) {
	if (!pObject) return;
	//if (0 == m_lpObjects.size()) return;

	m_lpObjects.remove_if([&pObject](CObject* pO) {
		return pObject == pO;
	});
}

//--------------------------container �Һ� �Լ�---------------------------------

CAnimateContainer::CAnimateContainer(ID3D11Device* pd3dDevice, ID3D11DeviceContext* pd3dDeviceContext) : DXObject(pd3dDevice, pd3dDeviceContext) {
	
}
CAnimateContainer::~CAnimateContainer() {

}