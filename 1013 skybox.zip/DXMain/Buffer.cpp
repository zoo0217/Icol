#include "stdafx.h"
#include "Buffer.h"


void** CBuffer::Map() {

	for (int i = 0; i < m_nBuffers; ++i) {
		m_pd3dDeviceContext->Map(m_ppd3dBuffer[i], 0, D3D11_MAP_WRITE_DISCARD, 0, &m_pMappedData[i]);
		m_ppData[i] = m_pMappedData[i].pData;
	}

	return m_ppData;
}

void CBuffer::Unmap() {
	for (int i = 0; i < m_nBuffers; ++i) {
		m_pd3dDeviceContext->Unmap(m_ppd3dBuffer[i], 0);
	}
}


CBuffer::CBuffer(ID3D11Device* pd3dDevice, ID3D11DeviceContext* pd3dDeviceContext) : DXObject(pd3dDevice, pd3dDeviceContext) { }
CBuffer::~CBuffer() { };

