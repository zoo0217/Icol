#include "stdafx.h"
#include "Texture.h"

bool CTexture::Begin(int nTextures, UINT* pSlots, _TCHAR(*ppstrFilePaths)[128], UINT* pBindFlags, shared_ptr<CSampler> pSampler, shared_ptr<CConstantBuffer> pConstantBuffer, bool bArray ){
	//sampler
	m_pSampler = pSampler;
	//constant buffer
	m_pConstantBuffer = pConstantBuffer;

	//texture
	m_nTextures = nTextures;
	m_pTextureStartSlots = new UINT[m_nTextures];
	m_ppd3dsrvTextures = new ID3D11ShaderResourceView*[m_nTextures];
	m_pBindFlags = new UINT[m_nTextures];

	if (false == bArray) {
		for (int i = 0; i < m_nTextures; ++i) {
			m_pTextureStartSlots[i] = pSlots[i];
			D3DX11CreateShaderResourceViewFromFile(m_pd3dDevice, ppstrFilePaths[i], NULL, NULL, &m_ppd3dsrvTextures[i], NULL);
			m_pBindFlags[i] = pBindFlags[i];
		}
	}
	else {
		m_pTextureStartSlots[0] = pSlots[0];
		m_ppd3dsrvTextures[0] = CreateTexture2DArraySRV(ppstrFilePaths, nTextures);
		m_pBindFlags[0] = pBindFlags[0];
		m_nTextures = 1;
	}
	return true;
}
bool CTexture::Begin(int nTextures, UINT* pSlots, ID3D11ShaderResourceView** ppShaderResourceView, UINT* pBindFlags, shared_ptr<CSampler> pSampler, shared_ptr<CConstantBuffer> pConstantBuffer, bool bArray ) {
	//sampler
	m_pSampler = pSampler;
	//constant buffer
	m_pConstantBuffer = pConstantBuffer;

	//texture
	m_nTextures = nTextures;
	m_pTextureStartSlots = new UINT[m_nTextures];
	m_ppd3dsrvTextures = new ID3D11ShaderResourceView*[m_nTextures];
	m_pBindFlags = new UINT[m_nTextures];

	//srv�� �̹� ����� �� �ִٸ� ��. array�� ���� �Ұ�
	for (int i = 0; i < m_nTextures; ++i) {
		m_pTextureStartSlots[i] = pSlots[i];
		m_ppd3dsrvTextures[i] = ppShaderResourceView[i];
		m_pBindFlags[i] = pBindFlags[i];
	}

	return true;
}
bool CTexture::End() {
	//sampler
	if (m_pSampler) {
		m_pSampler->End();
	}
	//constantbuffer
	if (m_pConstantBuffer) {
		m_pConstantBuffer->End();
	}

	//texture
	for (int i = 0; i < m_nTextures; ++i) {
		if (m_ppd3dsrvTextures[i]) m_ppd3dsrvTextures[i]->Release();
	}
	delete[] m_ppd3dsrvTextures;

	return true;
}

void CTexture::SetShaderState() {
	//sampler
	if(m_pSampler) m_pSampler->SetShaderState();
	//constant buffer
	if(m_pConstantBuffer) m_pConstantBuffer->SetShaderState();

	//texture
	for (int i = 0; i < m_nTextures; ++i) {
		if (m_pBindFlags[i] & BIND_VS) {
			m_pd3dDeviceContext->VSSetShaderResources(m_pTextureStartSlots[i], 1, &m_ppd3dsrvTextures[i]);
		}
		if (m_pBindFlags[i] & BIND_DS) {
			m_pd3dDeviceContext->DSSetShaderResources(m_pTextureStartSlots[i], 1, &m_ppd3dsrvTextures[i]);
		}
		if (m_pBindFlags[i] & BIND_HS) {
			m_pd3dDeviceContext->HSSetShaderResources(m_pTextureStartSlots[i], 1, &m_ppd3dsrvTextures[i]);
		}
		if (m_pBindFlags[i] & BIND_GS) {
			m_pd3dDeviceContext->GSSetShaderResources(m_pTextureStartSlots[i], 1, &m_ppd3dsrvTextures[i]);
		}
		if (m_pBindFlags[i] & BIND_PS) {
			m_pd3dDeviceContext->PSSetShaderResources(m_pTextureStartSlots[i], 1, &m_ppd3dsrvTextures[i]);
		}
		if (m_pBindFlags[i] & BIND_CS) {
			m_pd3dDeviceContext->CSSetShaderResources(m_pTextureStartSlots[i], 1, &m_ppd3dsrvTextures[i]);
		}
	}
}
void CTexture::CleanShaderState() {
	//sampler
	if(m_pSampler) m_pSampler->CleanShaderState();
	//constant buffer
	if(m_pConstantBuffer) m_pConstantBuffer->CleanShaderState();

	//texture
	ID3D11ShaderResourceView* pSRVs[1] = { nullptr };
	for (int i = 0; i < m_nTextures; ++i) {
		if (m_pBindFlags[i] & BIND_VS) {
			m_pd3dDeviceContext->VSSetShaderResources(m_pTextureStartSlots[i], 1, pSRVs);
		}
		if (m_pBindFlags[i] & BIND_DS) {
			m_pd3dDeviceContext->DSSetShaderResources(m_pTextureStartSlots[i], 1, pSRVs);
		}
		if (m_pBindFlags[i] & BIND_HS) {
			m_pd3dDeviceContext->HSSetShaderResources(m_pTextureStartSlots[i], 1, pSRVs);
		}
		if (m_pBindFlags[i] & BIND_GS) {
			m_pd3dDeviceContext->GSSetShaderResources(m_pTextureStartSlots[i], 1, pSRVs);
		}
		if (m_pBindFlags[i] & BIND_PS) {
			m_pd3dDeviceContext->PSSetShaderResources(m_pTextureStartSlots[i], 1, pSRVs);
		}
		if (m_pBindFlags[i] & BIND_CS) {
			m_pd3dDeviceContext->CSSetShaderResources(m_pTextureStartSlots[i], 1, pSRVs);
		}
	}

}

void CTexture::UpdateShaderState() {
	//update texture matrix
	if (m_pConstantBuffer) m_pConstantBuffer->UpdateShaderState();
}



void CTexture::SetSampler(shared_ptr<CSampler> pSampler){
	if (!pSampler) return;
	m_pSampler = pSampler;
}
void CTexture::SetConstantBuffer(shared_ptr<CConstantBuffer> pConstantBuffer) {
	if (!pConstantBuffer) return;
	m_pConstantBuffer = pConstantBuffer;
}

ID3D11ShaderResourceView* CTexture::CreateTexture2DArraySRV(_TCHAR(*ppstrFilePaths)[128], UINT nTextures){
	
	D3DX11_IMAGE_LOAD_INFO d3dxImageLoadInfo;
	d3dxImageLoadInfo.Width = D3DX11_FROM_FILE;
	d3dxImageLoadInfo.Height = D3DX11_FROM_FILE;
	d3dxImageLoadInfo.Depth = D3DX11_FROM_FILE;
	d3dxImageLoadInfo.FirstMipLevel = 0;
	d3dxImageLoadInfo.MipLevels = D3DX11_FROM_FILE;
	d3dxImageLoadInfo.Usage = D3D11_USAGE_STAGING;
	d3dxImageLoadInfo.BindFlags = 0;
	d3dxImageLoadInfo.CpuAccessFlags = D3D11_CPU_ACCESS_WRITE | D3D11_CPU_ACCESS_READ;
	d3dxImageLoadInfo.MiscFlags = 0;
	d3dxImageLoadInfo.Format = DXGI_FORMAT_FROM_FILE; //DXGI_FORMAT_R8G8B8A8_UNORM
	d3dxImageLoadInfo.Filter = D3DX11_FILTER_NONE;
	d3dxImageLoadInfo.MipFilter = D3DX11_FILTER_LINEAR;
	d3dxImageLoadInfo.pSrcInfo = 0;

	ID3D11Texture2D **ppd3dTextures = new ID3D11Texture2D*[nTextures];
	for (UINT i = 0; i < nTextures; i++) D3DX11CreateTextureFromFile(m_pd3dDevice, ppstrFilePaths[i], &d3dxImageLoadInfo, 0, (ID3D11Resource **)&ppd3dTextures[i], 0);

	D3D11_TEXTURE2D_DESC d3dTexure2DDesc;
	ppd3dTextures[0]->GetDesc(&d3dTexure2DDesc);

	D3D11_TEXTURE2D_DESC d3dTexture2DArrayDesc;
	d3dTexture2DArrayDesc.Width = d3dTexure2DDesc.Width;
	d3dTexture2DArrayDesc.Height = d3dTexure2DDesc.Height;
	d3dTexture2DArrayDesc.MipLevels = d3dTexure2DDesc.MipLevels;
	d3dTexture2DArrayDesc.ArraySize = nTextures;
	d3dTexture2DArrayDesc.Format = d3dTexure2DDesc.Format;
	d3dTexture2DArrayDesc.SampleDesc.Count = 1;
	d3dTexture2DArrayDesc.SampleDesc.Quality = 0;
	d3dTexture2DArrayDesc.Usage = D3D11_USAGE_DEFAULT;
	d3dTexture2DArrayDesc.BindFlags = D3D11_BIND_SHADER_RESOURCE;
	d3dTexture2DArrayDesc.CPUAccessFlags = 0;
	d3dTexture2DArrayDesc.MiscFlags = 0;

	ID3D11Texture2D *pd3dTexture2DArray;
	m_pd3dDevice->CreateTexture2D(&d3dTexture2DArrayDesc, 0, &pd3dTexture2DArray);

	D3D11_MAPPED_SUBRESOURCE d3dMappedTexture2D;
	for (UINT t = 0; t < nTextures; t++)
	{
		for (UINT m = 0; m < d3dTexure2DDesc.MipLevels; m++)
		{
	//? map �� ��? ������?
			m_pd3dDeviceContext->Map(ppd3dTextures[t], m, D3D11_MAP_READ, 0, &d3dMappedTexture2D);
			m_pd3dDeviceContext->UpdateSubresource(pd3dTexture2DArray, D3D11CalcSubresource(m, t, d3dTexure2DDesc.MipLevels), 0, d3dMappedTexture2D.pData, d3dMappedTexture2D.RowPitch, d3dMappedTexture2D.DepthPitch);
			m_pd3dDeviceContext->Unmap(ppd3dTextures[t], m);
		}
	}

	D3D11_SHADER_RESOURCE_VIEW_DESC d3dTextureSRVDesc;
	ZeroMemory(&d3dTextureSRVDesc, sizeof(D3D11_SHADER_RESOURCE_VIEW_DESC));
	d3dTextureSRVDesc.Format = d3dTexture2DArrayDesc.Format;
	d3dTextureSRVDesc.ViewDimension = D3D11_SRV_DIMENSION_TEXTURE2DARRAY;
	d3dTextureSRVDesc.Texture2DArray.MostDetailedMip = 0;
	d3dTextureSRVDesc.Texture2DArray.MipLevels = d3dTexture2DArrayDesc.MipLevels;
	d3dTextureSRVDesc.Texture2DArray.FirstArraySlice = 0;
	d3dTextureSRVDesc.Texture2DArray.ArraySize = nTextures;

	ID3D11ShaderResourceView *pd3dsrvTextureArray;
	m_pd3dDevice->CreateShaderResourceView(pd3dTexture2DArray, &d3dTextureSRVDesc, &pd3dsrvTextureArray);

	if (pd3dTexture2DArray) pd3dTexture2DArray->Release();

	for (UINT i = 0; i < nTextures; i++) if (ppd3dTextures[i]) ppd3dTextures[i]->Release();
	delete[] ppd3dTextures;

	return(pd3dsrvTextureArray);
}

CTexture::CTexture(ID3D11Device* pd3dDevice, ID3D11DeviceContext* pd3dDeviceContext) : DXObject(pd3dDevice, pd3dDeviceContext) { }
CTexture::~CTexture() { };

