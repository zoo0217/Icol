#pragma once 

#include "DXObject.h"
#include "Camera.h"
#include "RenderContainer.h"

class CLayer : public DXObject {
public:
	//---------------------------dxobject---------------------------------
	bool Begin() { return true; }
	virtual bool End() { return true; };

	virtual void SetShaderState() {};
	virtual void CleanShaderState() {};

	virtual void UpdateShaderState() {};
	//---------------------------dxobject---------------------------------

	//--------------------------layer---------------------------------
	virtual void RenderExcute() {};
	void Render();

	mapRenderContainer& GetRenderContainerMap() { return m_mRenderContainer; }
	//--------------------------layer---------------------------------


private:
	//begin func
	virtual void CreateShaderState() {};

protected:
	//rendercontainer map!
	mapRenderContainer m_mRenderContainer;

	shared_ptr<CCamera> m_pCamera{ nullptr };

public:
	CLayer(shared_ptr<CCamera> pCamera, ID3D11Device* pd3dDevice, ID3D11DeviceContext* pd3dDeviceContext);
	virtual ~CLayer();

};
