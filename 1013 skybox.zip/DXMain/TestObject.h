#pragma once
#include "Object.h"
#include "RotateComponent.h"

class CTestObject : public CObject {

public:
	//----------------------------dxobject-----------------------------
	bool Begin();
	virtual bool End();
	//----------------------------dxobject-----------------------------

private:


public:
	CTestObject();
	~CTestObject();
};
