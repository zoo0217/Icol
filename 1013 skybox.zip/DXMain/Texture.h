#pragma once
#include "DXObject.h"
#include "Sampler.h"
#include "ConstantBuffer.h"

class CTexture : public DXObject {
public:
	
	//texture ������
	bool Begin(int nTextures, UINT* pSlot, _TCHAR(*ppstrFilePaths)[128], UINT* pBindFlag, shared_ptr<CSampler> pSampler, shared_ptr<CConstantBuffer> pConstantBuffer, bool bArray = false);
	//�ϼ��� srv set
	bool Begin(int nTextures, UINT* pSlots, ID3D11ShaderResourceView** ppShaderResourceView, UINT* pBindFlags, shared_ptr<CSampler> pSampler, shared_ptr<CConstantBuffer> pConstantBuffer, bool bArray = false);
	
	virtual bool End();

	virtual void SetShaderState();
	virtual void CleanShaderState();

	virtual void UpdateShaderState();

	//setter
	void SetSampler(shared_ptr<CSampler> pSampler);
	void SetConstantBuffer(shared_ptr<CConstantBuffer> pConstantBuffer);
	//getter
	ID3D11ShaderResourceView** GetShaderResourceViews() { return m_ppd3dsrvTextures; }
	ID3D11ShaderResourceView* GetShaderResourceView(int index) { return m_ppd3dsrvTextures[index]; }
	shared_ptr<CSampler> GetSampler() { return m_pSampler; }

	ID3D11ShaderResourceView *CreateTexture2DArraySRV(_TCHAR(*ppstrFilePaths)[128], UINT nTextures);
protected:	
	//texture ������
	int								m_nTextures{ 0 };
	ID3D11ShaderResourceView**		m_ppd3dsrvTextures{ nullptr };
	UINT*							m_pTextureStartSlots{ nullptr };
	UINT*							m_pBindFlags{ nullptr };

	//�� �ȿ� �������� dx��ü���� ������
	//smapler ������ 
	shared_ptr<CSampler>			m_pSampler{ nullptr };

	//buffer ������
	shared_ptr<CConstantBuffer>		m_pConstantBuffer{ nullptr };
	
public:
	CTexture(ID3D11Device* pd3dDevice, ID3D11DeviceContext* pd3dDeviceContext);
	virtual ~CTexture();

};