#include "stdafx.h"
#include "Light.h"

bool CLight::Begin() { 

	return CObject::Begin(); 
};

//instance buffer controll base
void CLight::SetInstanceBufferInfo(void* pMappedResource, int& nInstance, shared_ptr<CCamera> pCamera) {
	//����ȯ
	VS_VB_INSTANCE *pnInstances = (VS_VB_INSTANCE *)pMappedResource;
	//transpose ���� ���� ����
	pnInstances[nInstance].m_xmmtxWorld = XMMatrixTranspose(GetWorldMtx());

}