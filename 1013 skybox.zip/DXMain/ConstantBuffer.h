#pragma once
#include "Buffer.h"


class CConstantBuffer : public CBuffer {
public:
	bool Begin(int nBuffers, UINT* pSlots, UINT* pObjects, UINT* pBufferStrides, UINT* pBindFlags, UINT *pOffsets);
	virtual bool End();

	virtual void SetShaderState();
	virtual void CleanShaderState();

	virtual void UpdateShaderState();
	
private:
	ID3D11Buffer* CreateConstantBuffer(UINT nByteWidth);

	//buffer info
	UINT*							m_pSlots{ nullptr };

	//bind flag default is none �ݵ�� set����� �Ѵ�.
	UINT*							m_pBindFlags{ nullptr };
protected:
	
public:
	CConstantBuffer(ID3D11Device* pd3dDevice, ID3D11DeviceContext* pd3dDeviceContext);
	virtual ~CConstantBuffer();

};