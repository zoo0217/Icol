#include "stdafx.h"
#include "Layer.h"

CLayer::CLayer(shared_ptr<CCamera> pCamera, ID3D11Device* pd3dDevice, ID3D11DeviceContext* pd3dDeviceContext) : DXObject(pd3dDevice, pd3dDeviceContext) {
	m_pCamera = pCamera;
}
CLayer::~CLayer() {

}

void CLayer::Render() {
	UpdateShaderState();
	SetShaderState();
	RenderExcute();
	CleanShaderState();
}
