#pragma once
#include "DXObject.h"



class CSampler : public DXObject {
public:
	bool Begin(int nSamplers, UINT* pSlots, D3D11_TEXTURE_ADDRESS_MODE* pModes, D3D11_FILTER* pFilters, D3D11_COMPARISON_FUNC* pComparisionFuncs, float* pMinLODs, float* pMaxLODs, UINT* pBindFlags);
	virtual bool End();

	virtual void SetShaderState();
	virtual void CleanShaderState();

	virtual void UpdateShaderState();


protected:
	//smapler ������
	int								m_nSamplers{ 0 };
	ID3D11SamplerState**			m_ppd3dSamplerState{ nullptr };
	UINT*							m_pSamplerStartSlots{ nullptr };

	//flag ������
	UINT*							m_pBindFlags{ nullptr };

public:
	CSampler(ID3D11Device* pd3dDevice, ID3D11DeviceContext* pd3dDeviceContext);
	virtual ~CSampler();

};