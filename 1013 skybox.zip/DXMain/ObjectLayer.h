#pragma once
#include "Layer.h"
#include "SkyBox.h"

class CRenderContainerSeller;

class CObjectLayer : public CLayer {
public:
	//---------------------------dxobject---------------------------------
	bool Begin(CRenderContainerSeller* pSeller);
	virtual bool End();

	virtual void SetShaderState();
	virtual void CleanShaderState();

	virtual void UpdateShaderState();
	//---------------------------dxobject---------------------------------

	//--------------------------container---------------------------------
	virtual void RenderExcute();
	//--------------------------container---------------------------------

private:
	virtual void CreateShaderState();

	ID3D11DepthStencilState* m_pd3dDepthStencilState{ nullptr };
	ID3D11DepthStencilState* m_pd3dTempDepthStencilState{ nullptr };
	UINT m_TempStencil{ 0 };

public:
	CObjectLayer(shared_ptr<CCamera> pCamera, ID3D11Device* pd3dDevice, ID3D11DeviceContext* pd3dDeviceContext);
	virtual ~CObjectLayer();

};