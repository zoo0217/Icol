#pragma once
#include "Mesh.h"


class CDirectionalLightMesh : public CMesh {

public:
	//----------------------------dxobject-----------------------------
	virtual void SetShaderState();
	virtual void CleanShaderState() { }
	//----------------------------dxobject-----------------------------

	//---------------------------mesh----------------------------------
	virtual void RenderExcute(UINT nnInstance);
	//begin func
	virtual bool CreateVertexBuffer();
	virtual bool CreateIndexBuffer();
	//begin func
	//---------------------------mesh----------------------------------
private:
	//----------------------vertex buffers---------------------------

	//----------------------vertex buffers---------------------------

public:
	CDirectionalLightMesh(ID3D11Device* pd3dDevice, ID3D11DeviceContext* pd3dDeviceContext);
	virtual ~CDirectionalLightMesh();
};