#pragma once

#include "Component.h"
#include "Camera.h"

//rendercontainer ���� Ŭ����
class CRenderContainer;
class CRenderContainerSeller;

typedef std::pair<component_id, CComponent*> pairComponent;
typedef std::map<component_id, CComponent*> mapComponent;


struct VS_VB_INSTANCE {
	XMMATRIX m_xmmtxWorld;
};


class CObject {
public:
	//----------------------------object-----------------------------
	bool Begin();
	virtual bool End();
	//----------------------------object-----------------------------

	void SetPosition(XMVECTOR pos);

	XMVECTOR GetRight();
	XMVECTOR GetUp();
	XMVECTOR GetLook();
	void SetRight(XMVECTOR xmvRight);
	void SetUp(XMVECTOR xmvUp);
	void SetLook(XMVECTOR xmvLook);

	XMVECTOR GetPosition();
	object_id GetObjectID() { return m_objectID; }

	virtual XMMATRIX GetWorldMtx();
	void SetWorldMtx(XMMATRIX mtxWorld);

	//test animate func
	virtual void Move(XMVECTOR xmvDir, float fDistance);
	virtual void Rotate(float x = 0.0f, float y = 0.0f, float z = 0.0f);
	//----------------------------component------------------------
	//�ڽ��� component ���� + 
	virtual void Animate(float fTimeElapsed);

	//Component Set
	bool SetComponent(CComponent* pComponenet);

	//Get
	CComponent* GetComponenet(const component_id& componenetID);
	const CComponent* GetComponenet(const component_id& componenetID)const;

	//Clear
	void ClearComponents();
	//----------------------------component------------------------

	//instance buffer controll
	virtual void SetInstanceBufferInfo(void** ppMappedResources, int& nInstance, shared_ptr<CCamera> pCamera);
	//render container controll
	virtual void RegistToContainer();
	//virtual void RegistToLayer(mapLayer & mLayer);
	void SetRenderContainer(CRenderContainerSeller* pSeller);
protected:
	//world
	XMFLOAT4X4 m_xmf4x4World;
	mapComponent m_mapComponents;

	CRenderContainer* m_pRenderContainer{ nullptr };
	//object_id
	object_id m_objectID{ object_id::OBJECT_END };
public:
	CObject();
	virtual ~CObject();
};