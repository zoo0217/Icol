#include "stdafx.h"
#include "CapsuleLightMesh.h"


bool CCapsuleLightMesh::CreateVertexBuffer() {
	m_nVertices = 2;
	m_d3dPrimitiveTopology = D3D11_PRIMITIVE_TOPOLOGY_1_CONTROL_POINT_PATCHLIST;

	m_ppd3dVertexBuffers = nullptr;

	return true;
}
bool CCapsuleLightMesh::CreateIndexBuffer() {

	return true;
}

void CCapsuleLightMesh::SetShaderState() {
	//�޽�
	m_pd3dDeviceContext->IASetPrimitiveTopology(m_d3dPrimitiveTopology);

	// ������ ���۸� �����մϴ�.
	m_pd3dDeviceContext->IASetVertexBuffers(m_nStartSlot, m_nVertexBuffers, m_ppd3dVertexBuffers, m_pnVertexStrides, m_pnVertexOffsets);

	// �ε��� ���۸� �����մϴ�.
	m_pd3dDeviceContext->IASetIndexBuffer(m_pd3dIndexBuffer, m_d3dIndexFormat, m_nIndexOffset);


}

void CCapsuleLightMesh::RenderExcute(UINT nInstance) {

	if (m_pd3dIndexBuffer)
		m_pd3dDeviceContext->DrawIndexedInstanced(m_nIndices, nInstance, m_nStartIndexLocation, m_nBaseVertexLocation, m_nStartInstanceLocation);
	else
		m_pd3dDeviceContext->DrawInstanced(m_nVertices, nInstance, m_nStartVertexLocation, m_nStartInstanceLocation);

}

CCapsuleLightMesh::CCapsuleLightMesh(ID3D11Device* pd3dDevice, ID3D11DeviceContext* pd3dDeviceContext) : CMesh(pd3dDevice, pd3dDeviceContext) {

}
CCapsuleLightMesh::~CCapsuleLightMesh() {

}