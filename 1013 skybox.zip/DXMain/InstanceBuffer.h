#pragma once
#include "Buffer.h"


class CInstanceBuffer : public CBuffer {
public:
	bool Begin(int nBuffers, UINT* pObjects, UINT* pBufferStrides, UINT* pOffsets);
	virtual bool End();

	virtual void SetShaderState();
	virtual void CleanShaderState();

	virtual void UpdateShaderState();

private:
	ID3D11Buffer* CreateInstanceBuffer(UINT nByteWidth);

protected:

public:
	CInstanceBuffer(ID3D11Device* pd3dDevice, ID3D11DeviceContext* pd3dDeviceContext);
	virtual ~CInstanceBuffer();

};