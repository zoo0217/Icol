#pragma once

#include "DXObject.h"

// �������� �����͸� ������ ���̴��� ������ �� ���˴ϴ�.
struct VertexPositionColor
{
	DirectX::XMFLOAT3 pos;
	DirectX::XMFLOAT3 color;
};

class CMesh : public DXObject {

public:
	//----------------------------dxobject-----------------------------
	bool Begin();
	virtual bool End();

	virtual void SetShaderState() { }
	virtual void CleanShaderState() { }
	//----------------------------dxobject-----------------------------

	//---------------------------mesh----------------------------------
	virtual void RenderExcute(UINT nInstance) { }
	//begin func
	virtual bool CreateVertexBuffer() { return true; }
	virtual bool CreateIndexBuffer() { return true; }
	//begin func

	void CMesh::CalculateVertexNormal(XMVECTOR *pxmvNormals);
	void CMesh::SetTriAngleListVertexNormal(XMVECTOR *pxmvNormals);
	XMVECTOR CMesh::CalculateTriAngleNormal(UINT nIndex0, UINT nIndex1, UINT nIndex2);
	void CMesh::SetAverageVertexNormal(XMVECTOR* pxmvNormals, int nPrimitives, int nOffset, bool bStrip);

	void AssembleToVertexBuffer(int nBuffers, ID3D11Buffer** ppd3dBuffers, UINT* pnBufferStrides, UINT* pnBufferOffsets);
	//---------------------------mesh----------------------------------
protected:
	D3D11_PRIMITIVE_TOPOLOGY m_d3dPrimitiveTopology{ D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST };

	UINT									m_nVertices{ 0 };
	UINT									m_nIndices{ 0 };
	UINT*									m_pnIndices{ nullptr };
	XMFLOAT3*								m_pnVertices{ nullptr };

	//-----------------------------------render option-------------------------
	UINT m_nStartIndexLocation{ 0 };
	UINT m_nStartVertexLocation{ 0 };
	UINT m_nBaseVertexLocation{ 0 };
	UINT m_nStartInstanceLocation{ 0 };
	//-----------------------------------render option-------------------------

	//---------------------------------vertex buffer------------------------
	UINT								m_nStartSlot{ 0 };
	int									m_nVertexBuffers{ 0 };
	UINT*								m_pnVertexOffsets{ 0 };
	UINT*								m_pnVertexStrides{ 0 };
	ID3D11Buffer**						m_ppd3dVertexBuffers{ nullptr };
	//---------------------------------vertex buffer------------------------
	
	//---------------------------------index buffer-------------------------
	DXGI_FORMAT							m_d3dIndexFormat{ DXGI_FORMAT_R16_UINT };
	ID3D11Buffer*						m_pd3dIndexBuffer{ nullptr };
	UINT								m_nIndexOffset{ 0 };
	//---------------------------------index buffer-------------------------
public:
	CMesh(ID3D11Device* pd3dDevice, ID3D11DeviceContext* pd3dDeviceContext);
	virtual ~CMesh();
};