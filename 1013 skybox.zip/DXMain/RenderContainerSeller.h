#pragma once
//#include "Camera.h"

#include "DirectionalLightMesh.h"
#include "PointLightMesh.h"
#include "SpotLightMesh.h"
#include "CapsuleLightMesh.h"
#include "TestMesh.h"
#include "PlaneMesh.h"
#include "TestDeferredMesh.h"
#include "SkyBoxMesh.h"//skybox

#include "Light.h"
#include "DirectionalLight.h"
#include "PointLight.h"
#include "SpotLight.h"
#include "CapsuleLight.h"
#include "SkyBox.h"//skybox

#include "InstanceBuffer.h"
#include "ConstantBuffer.h"

#include "Material.h"

#include "Texture.h"
#include "Sampler.h"

#include "RenderContainer.h"

class CRenderContainerSeller : public DXObject {
public:
	bool Begin();
	bool End();

	CRenderContainer* GetRenderContainer(object_id objectid);

private:
	//�̰� ��¥ rendercontainer
	mapRenderContainer m_mRenderContainer;
	//camera
	shared_ptr<CCamera> m_pCamera{ nullptr };

	//shader
	shared_ptr<CRenderShader> m_pCoreShader{ nullptr };
	shared_ptr<CRenderShader> m_pDirectionalLightShader{ nullptr };
	shared_ptr<CRenderShader> m_pPointLightShader{ nullptr };
	shared_ptr<CRenderShader> m_pSpotLightShader{ nullptr };
	shared_ptr<CRenderShader> m_pCapsuleLightShader{ nullptr };
	shared_ptr<CRenderShader> m_pPostProcessingShader{ nullptr };
	shared_ptr<CRenderShader> m_pSkyBoxShader{ nullptr };

	//material
	shared_ptr<CMaterial> m_pCoreMaterial{ nullptr };
	shared_ptr<CMaterial> m_pBoostMaterial{ nullptr };
	shared_ptr<CMaterial> m_pWeaponMaterial{ nullptr };
	shared_ptr<CMaterial> m_pAdaptorMaterial{ nullptr };
	shared_ptr<CMaterial> m_pPlaneMaterial{ nullptr };
	shared_ptr<CMaterial> m_pSkyBoxMaterial{ nullptr };

	//mesh
	shared_ptr<CMesh> m_pTestRectMesh1{ nullptr };
	shared_ptr<CMesh> m_pTestRectMesh2{ nullptr };
	shared_ptr<CMesh> m_pTestRectMesh3{ nullptr };
	shared_ptr<CMesh> m_pTestRectMesh4{ nullptr };
	shared_ptr<CMesh> m_pTestRectMesh5{ nullptr };
	shared_ptr<CMesh> m_pPlaneMesh{ nullptr };
	shared_ptr<CMesh> m_pDirectionalLightMesh{ nullptr };
	shared_ptr<CMesh> m_pPointLightMesh{ nullptr };
	shared_ptr<CMesh> m_pSpotLightMesh{ nullptr };
	shared_ptr<CMesh> m_pCapsuleLightMesh{ nullptr };
	shared_ptr<CMesh> m_pPostProcessingMesh{ nullptr };
	shared_ptr<CMesh> m_pSkyBoxMesh{ nullptr };

	//constant bufer
	shared_ptr<CInstanceBuffer> m_pNormalInstanceBuffer1{ nullptr };
	shared_ptr<CInstanceBuffer> m_pNormalInstanceBuffer2{ nullptr };
	shared_ptr<CInstanceBuffer> m_pNormalInstanceBuffer3{ nullptr };
	shared_ptr<CInstanceBuffer> m_pNormalInstanceBuffer4{ nullptr };
	shared_ptr<CInstanceBuffer> m_pNormalInstanceBuffer5{ nullptr };
	shared_ptr<CInstanceBuffer> m_pPlaneInstanceBuffer{ nullptr };
	shared_ptr<CInstanceBuffer> m_pSkyBoxBuffer{ nullptr };

	shared_ptr<CConstantBuffer> m_pDirectionalLightBuffer{ nullptr };
	shared_ptr<CConstantBuffer> m_pPointLightBuffer{ nullptr };
	shared_ptr<CConstantBuffer> m_pSpotLightBuffer{ nullptr };
	shared_ptr<CConstantBuffer> m_pCapsuleLightBuffer{ nullptr };

	shared_ptr<CTexture> m_pSkyBoxTexture{ nullptr };
	shared_ptr<CSampler> m_pSkyBoxSampler{ nullptr };
	//max normal instancing num
	UINT m_nMaxNormalObjects{ 1000 };
public:
	CRenderContainerSeller(shared_ptr<CCamera> pCamera, ID3D11Device* pd3dDevice, ID3D11DeviceContext* pd3dDeviceContext) : DXObject(pd3dDevice, pd3dDeviceContext) {
		m_pCamera = pCamera;
	}
};
