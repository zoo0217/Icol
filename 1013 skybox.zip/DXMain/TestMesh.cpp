#include "stdafx.h"
#include "TestMesh.h"

/*������ ������ ��������(Random) �����ϱ� ���� ����Ѵ�. �� ������ ������ ����(Random Number)�� �����Ͽ� �����Ѵ�.*/
#define RANDOM_COLOR XMFLOAT4(((rand() * 0xFFFFFF) / RAND_MAX),((rand() * 0xFFFFFF) / RAND_MAX),((rand() * 0xFFFFFF) / RAND_MAX),((rand() * 0xFFFFFF) / RAND_MAX))


#define WIDTH 10
#define HEIGHT 10
#define DEPTH 10

bool CTestMesh::CreateVertexBuffer() {
	m_nVertices = 36;
	m_d3dPrimitiveTopology = D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST;

	float fx = WIDTH*0.5f, fy = HEIGHT*0.5f, fz = DEPTH*0.5f;

	m_pnVertices = new XMFLOAT3[m_nVertices];
	XMFLOAT2 pxmf2TexCoords[36];
	int i = 0;

	//������ü�� �� ��(�ﰢ�� 2��)�� �ϳ��� �ؽ��� �̹��� ��ü�� ���εǵ��� �ؽ��� ��ǥ�� �����Ѵ�.
	m_pnVertices[i] = XMFLOAT3(-fx, +fy, -fz);
	pxmf2TexCoords[i++] = XMFLOAT2(0.0f, 0.0f);
	m_pnVertices[i] = XMFLOAT3(+fx, +fy, -fz);
	pxmf2TexCoords[i++] = XMFLOAT2(1.0f, 0.0f);
	m_pnVertices[i] = XMFLOAT3(+fx, -fy, -fz);
	pxmf2TexCoords[i++] = XMFLOAT2(1.0f, 1.0f);

	m_pnVertices[i] = XMFLOAT3(-fx, +fy, -fz);
	pxmf2TexCoords[i++] = XMFLOAT2(0.0f, 0.0f);
	m_pnVertices[i] = XMFLOAT3(+fx, -fy, -fz);
	pxmf2TexCoords[i++] = XMFLOAT2(1.0f, 1.0f);
	m_pnVertices[i] = XMFLOAT3(-fx, -fy, -fz);
	pxmf2TexCoords[i++] = XMFLOAT2(0.0f, 1.0f);

	m_pnVertices[i] = XMFLOAT3(-fx, +fy, +fz);
	pxmf2TexCoords[i++] = XMFLOAT2(0.0f, 0.0f);
	m_pnVertices[i] = XMFLOAT3(+fx, +fy, +fz);
	pxmf2TexCoords[i++] = XMFLOAT2(1.0f, 0.0f);
	m_pnVertices[i] = XMFLOAT3(+fx, +fy, -fz);
	pxmf2TexCoords[i++] = XMFLOAT2(1.0f, 1.0f);

	m_pnVertices[i] = XMFLOAT3(-fx, +fy, +fz);
	pxmf2TexCoords[i++] = XMFLOAT2(0.0f, 0.0f);
	m_pnVertices[i] = XMFLOAT3(+fx, +fy, -fz);
	pxmf2TexCoords[i++] = XMFLOAT2(1.0f, 1.0f);
	m_pnVertices[i] = XMFLOAT3(-fx, +fy, -fz);
	pxmf2TexCoords[i++] = XMFLOAT2(0.0f, 1.0f);

	m_pnVertices[i] = XMFLOAT3(-fx, -fy, +fz);
	pxmf2TexCoords[i++] = XMFLOAT2(0.0f, 0.0f);
	m_pnVertices[i] = XMFLOAT3(+fx, -fy, +fz);
	pxmf2TexCoords[i++] = XMFLOAT2(1.0f, 0.0f);
	m_pnVertices[i] = XMFLOAT3(+fx, +fy, +fz);
	pxmf2TexCoords[i++] = XMFLOAT2(1.0f, 1.0f);

	m_pnVertices[i] = XMFLOAT3(-fx, -fy, +fz);
	pxmf2TexCoords[i++] = XMFLOAT2(0.0f, 0.0f);
	m_pnVertices[i] = XMFLOAT3(+fx, +fy, +fz);
	pxmf2TexCoords[i++] = XMFLOAT2(1.0f, 1.0f);
	m_pnVertices[i] = XMFLOAT3(-fx, +fy, +fz);
	pxmf2TexCoords[i++] = XMFLOAT2(0.0f, 1.0f);

	m_pnVertices[i] = XMFLOAT3(-fx, -fy, -fz);
	pxmf2TexCoords[i++] = XMFLOAT2(0.0f, 0.0f);
	m_pnVertices[i] = XMFLOAT3(+fx, -fy, -fz);
	pxmf2TexCoords[i++] = XMFLOAT2(1.0f, 0.0f);
	m_pnVertices[i] = XMFLOAT3(+fx, -fy, +fz);
	pxmf2TexCoords[i++] = XMFLOAT2(1.0f, 1.0f);

	m_pnVertices[i] = XMFLOAT3(-fx, -fy, -fz);
	pxmf2TexCoords[i++] = XMFLOAT2(0.0f, 0.0f);
	m_pnVertices[i] = XMFLOAT3(+fx, -fy, +fz);
	pxmf2TexCoords[i++] = XMFLOAT2(1.0f, 1.0f);
	m_pnVertices[i] = XMFLOAT3(-fx, -fy, +fz);
	pxmf2TexCoords[i++] = XMFLOAT2(0.0f, 1.0f);

	m_pnVertices[i] = XMFLOAT3(-fx, +fy, +fz);
	pxmf2TexCoords[i++] = XMFLOAT2(0.0f, 0.0f);
	m_pnVertices[i] = XMFLOAT3(-fx, +fy, -fz);
	pxmf2TexCoords[i++] = XMFLOAT2(1.0f, 0.0f);
	m_pnVertices[i] = XMFLOAT3(-fx, -fy, -fz);
	pxmf2TexCoords[i++] = XMFLOAT2(1.0f, 1.0f);

	m_pnVertices[i] = XMFLOAT3(-fx, +fy, +fz);
	pxmf2TexCoords[i++] = XMFLOAT2(0.0f, 0.0f);
	m_pnVertices[i] = XMFLOAT3(-fx, -fy, -fz);
	pxmf2TexCoords[i++] = XMFLOAT2(1.0f, 1.0f);
	m_pnVertices[i] = XMFLOAT3(-fx, -fy, +fz);
	pxmf2TexCoords[i++] = XMFLOAT2(0.0f, 1.0f);

	m_pnVertices[i] = XMFLOAT3(+fx, +fy, -fz);
	pxmf2TexCoords[i++] = XMFLOAT2(0.0f, 0.0f);
	m_pnVertices[i] = XMFLOAT3(+fx, +fy, +fz);
	pxmf2TexCoords[i++] = XMFLOAT2(1.0f, 0.0f);
	m_pnVertices[i] = XMFLOAT3(+fx, -fy, +fz);
	pxmf2TexCoords[i++] = XMFLOAT2(1.0f, 1.0f);

	m_pnVertices[i] = XMFLOAT3(+fx, +fy, -fz);
	pxmf2TexCoords[i++] = XMFLOAT2(0.0f, 0.0f);
	m_pnVertices[i] = XMFLOAT3(+fx, -fy, +fz);
	pxmf2TexCoords[i++] = XMFLOAT2(1.0f, 1.0f);
	m_pnVertices[i] = XMFLOAT3(+fx, -fy, -fz);
	pxmf2TexCoords[i++] = XMFLOAT2(0.0f, 1.0f);

	m_pd3dPositionBuffer = CreateBuffer(sizeof(XMFLOAT3), m_nVertices, m_pnVertices, D3D11_BIND_VERTEX_BUFFER, D3D11_USAGE_DEFAULT, 0);
	m_pd3dUVBuffer = CreateBuffer(sizeof(XMFLOAT3), m_nVertices, pxmf2TexCoords, D3D11_BIND_VERTEX_BUFFER, D3D11_USAGE_DEFAULT, 0);

	//���� ���͸� �����ϱ� ���� ���� �ڵ带 �߰��Ѵ�.
	XMVECTOR pxmvNormals[36];
	CalculateVertexNormal(pxmvNormals);
	XMFLOAT3 pxmf3Normals[36];
	for (int i = 0; i < 36; ++i) {
		XMStoreFloat3(&pxmf3Normals[i], pxmvNormals[i]);
	}
	m_pd3dNormalBuffer = CreateBuffer(sizeof(XMFLOAT3), m_nVertices, pxmf3Normals, D3D11_BIND_VERTEX_BUFFER, D3D11_USAGE_DEFAULT, 0);
	
	//������ ��ġ ����, ���� ����, �ؽ��� ��ǥ�� ���´�.
	ID3D11Buffer *pd3dBuffers[3] = { m_pd3dPositionBuffer, m_pd3dNormalBuffer, m_pd3dUVBuffer };
	UINT pnBufferStrides[3] = { sizeof(XMFLOAT3), sizeof(XMFLOAT3), sizeof(XMFLOAT2) };
	UINT pnBufferOffsets[3] = { 0, 0, 0 };
	AssembleToVertexBuffer(3, pd3dBuffers, pnBufferStrides, pnBufferOffsets);


	if (m_ppd3dVertexBuffers)	return true;

	return false;
}
bool CTestMesh::CreateIndexBuffer() {

	return true;

	m_nIndices = 18;

	short pIndices[18];
	pIndices[0] = 5; //5,6,4 - cw
	pIndices[1] = 6; //6,4,7 - ccw
	pIndices[2] = 4; //4,7,0 - cw
	pIndices[3] = 7; //7,0,3 - ccw
	pIndices[4] = 0; //0,3,1 - cw
	pIndices[5] = 3; //3,1,2 - ccw
	pIndices[6] = 1; //1,2,2 - cw 
	pIndices[7] = 2; //2,2,3 - ccw
	pIndices[8] = 2; //2,3,3 - cw  - Degenerated Index(2)
	pIndices[9] = 3; //3,3,7 - ccw - Degenerated Index(3)
	pIndices[10] = 3;//3,7,2 - cw  - Degenerated Index(3)
	pIndices[11] = 7;//7,2,6 - ccw
	pIndices[12] = 2;//2,6,1 - cw
	pIndices[13] = 6;//6,1,5 - ccw
	pIndices[14] = 1;//1,5,0 - cw
	pIndices[15] = 5;//5,0,4 - ccw
	pIndices[16] = 0;
	pIndices[17] = 4;
	/*UINT pIndices[36];
	//�� �ո�(Front) �簢���� ���� �ﰢ��
	pIndices[0] = 3; pIndices[1] = 1; pIndices[2] = 0;
	//�� �ո�(Front) �簢���� �Ʒ��� �ﰢ��
	pIndices[3] = 2; pIndices[4] = 1; pIndices[5] = 3;
	//�� ����(Top) �簢���� ���� �ﰢ��
	pIndices[6] = 0; pIndices[7] = 5; pIndices[8] = 4;
	//�� ����(Top) �簢���� �Ʒ��� �ﰢ��
	pIndices[9] = 1; pIndices[10] = 5; pIndices[11] = 0;
	//�� �޸�(Back) �簢���� ���� �ﰢ��
	pIndices[12] = 3; pIndices[13] = 4; pIndices[14] = 7;
	//�� �޸�(Back) �簢���� �Ʒ��� �ﰢ��
	pIndices[15] = 0; pIndices[16] = 4; pIndices[17] = 3;
	//�� �Ʒ���(Bottom) �簢���� ���� �ﰢ��
	pIndices[18] = 1; pIndices[19] = 6; pIndices[20] = 5;
	//�� �Ʒ���(Bottom) �簢���� �Ʒ��� �ﰢ��
	pIndices[21] = 2; pIndices[22] = 6; pIndices[23] = 1;
	//�� ����(Left) �簢���� ���� �ﰢ��
	pIndices[24] = 2; pIndices[25] = 7; pIndices[26] = 6;
	//�� ����(Left) �簢���� �Ʒ��� �ﰢ��
	pIndices[27] = 3; pIndices[28] = 7; pIndices[29] = 2;
	//�� ����(Right) �簢���� ���� �ﰢ��
	pIndices[30] = 6; pIndices[31] = 4; pIndices[32] = 5;
	//�� ����(Right) �簢���� �Ʒ��� �ﰢ��
	pIndices[33] = 7; pIndices[34] = 4; pIndices[35] = 6;
	*/
	D3D11_BUFFER_DESC d3dBufferDesc;
	ZeroMemory(&d3dBufferDesc, sizeof(D3D11_BUFFER_DESC));
	d3dBufferDesc.Usage = D3D11_USAGE_DEFAULT;
	d3dBufferDesc.ByteWidth = sizeof(UINT) * m_nIndices;
	d3dBufferDesc.BindFlags = D3D11_BIND_INDEX_BUFFER;
	d3dBufferDesc.CPUAccessFlags = 0;
	D3D11_SUBRESOURCE_DATA d3dBufferData;
	ZeroMemory(&d3dBufferData, sizeof(D3D11_SUBRESOURCE_DATA));
	d3dBufferData.pSysMem = pIndices;
	m_pd3dDevice->CreateBuffer(&d3dBufferDesc, &d3dBufferData, &m_pd3dIndexBuffer);


	if (m_pd3dIndexBuffer) return true;

	return false;
}

void CTestMesh::SetShaderState() {
	//�޽�
	m_pd3dDeviceContext->IASetPrimitiveTopology(m_d3dPrimitiveTopology);

	// ������ ���۸� �����մϴ�.
	m_pd3dDeviceContext->IASetVertexBuffers(m_nStartSlot, m_nVertexBuffers, m_ppd3dVertexBuffers, m_pnVertexStrides, m_pnVertexOffsets);

	// �ε��� ���۸� �����մϴ�.
	m_pd3dDeviceContext->IASetIndexBuffer(m_pd3dIndexBuffer,m_d3dIndexFormat, m_nIndexOffset);


}

void CTestMesh::RenderExcute(UINT nInstance) {

	if (m_pd3dIndexBuffer)
		m_pd3dDeviceContext->DrawIndexedInstanced(m_nIndices, nInstance, m_nStartIndexLocation, m_nBaseVertexLocation, m_nStartInstanceLocation);
	else
		m_pd3dDeviceContext->DrawInstanced(m_nVertices, nInstance, m_nStartVertexLocation, m_nStartInstanceLocation);

}

CTestMesh::CTestMesh(ID3D11Device* pd3dDevice, ID3D11DeviceContext* pd3dDeviceContext) : CMesh(pd3dDevice, pd3dDeviceContext) {

}
CTestMesh::~CTestMesh() {

}