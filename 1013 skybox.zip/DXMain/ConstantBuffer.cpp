#include "stdafx.h"
#include "ConstantBuffer.h"

bool CConstantBuffer::Begin(int nBuffers, UINT* pSlots, UINT* pObjects, UINT* pBufferStrides, UINT* pBindFlags, UINT *pOffsets) {
	//setdata
	m_pSlots = new UINT[nBuffers];
	m_pnObjects = new UINT[nBuffers];
	m_pBindFlags = new UINT[nBuffers];
	m_pBufferStrides = new UINT[nBuffers];
	m_pByteWidths = new UINT[nBuffers];
	m_ppd3dBuffer = new ID3D11Buffer*[nBuffers];
	m_pOffsets = new UINT[nBuffers];
	m_pMappedData = new D3D11_MAPPED_SUBRESOURCE[nBuffers];
	m_ppData = new void*[nBuffers];

	m_nBuffers = nBuffers;
	for (int i = 0; i < m_nBuffers; ++i) {
		m_pSlots[i] = pSlots[i];
		m_pBindFlags[i] = pBindFlags[i];
		m_pnObjects[i] = pObjects[i];
		m_pBufferStrides[i] = pBufferStrides[i];
		m_pByteWidths[i] = m_pnObjects[i] * m_pBufferStrides[i];
		m_pOffsets[i] = pOffsets[i];

		//create buffer
		m_ppd3dBuffer[i] = CreateConstantBuffer(m_pByteWidths[i]);
	}

	return true;
}

bool CConstantBuffer::End() {

	if (m_pSlots) delete[] m_pSlots;
	if (m_pnObjects) delete[] m_pnObjects;
	if (m_pBindFlags) delete[] m_pBindFlags;
	if (m_pBufferStrides) delete[] m_pBufferStrides;
	if (m_pByteWidths) delete[] m_pByteWidths;
	if (m_ppd3dBuffer) delete[] m_ppd3dBuffer;
	if (m_pMappedData) delete[] m_pMappedData;
	if (m_ppData) delete[] m_ppData;

	return true;
}

void CConstantBuffer::SetShaderState() {

	for (int i = 0; i < m_nBuffers; ++i) {
		ID3D11Buffer* pBuffers[1] = { m_ppd3dBuffer[i] };

		if (m_pBindFlags[i] & BIND_VS) {
			m_pd3dDeviceContext->VSSetConstantBuffers(m_pSlots[i], 1, pBuffers);
		}
		if (m_pBindFlags[i] & BIND_DS) {
			m_pd3dDeviceContext->DSSetConstantBuffers(m_pSlots[i], 1, pBuffers);
		}
		if (m_pBindFlags[i] & BIND_HS) {
			m_pd3dDeviceContext->HSSetConstantBuffers(m_pSlots[i], 1, pBuffers);
		}
		if (m_pBindFlags[i] & BIND_GS) {
			m_pd3dDeviceContext->GSSetConstantBuffers(m_pSlots[i], 1, pBuffers);
		}
		if (m_pBindFlags[i] & BIND_PS) {
			m_pd3dDeviceContext->PSSetConstantBuffers(m_pSlots[i], 1, pBuffers);
		}
		if (m_pBindFlags[i] & BIND_CS) {
			m_pd3dDeviceContext->CSSetConstantBuffers(m_pSlots[i], 1, pBuffers);
		}
	}
}
void CConstantBuffer::CleanShaderState() {
	
	ID3D11Buffer* pBuffers[1] = { nullptr };
	for (int i = 0; i < m_nBuffers; ++i) {

		if (m_pBindFlags[i] & BIND_VS) {
			m_pd3dDeviceContext->VSSetConstantBuffers(m_pSlots[i], 1, pBuffers);
		}
		if (m_pBindFlags[i] & BIND_DS) {
			m_pd3dDeviceContext->DSSetConstantBuffers(m_pSlots[i], 1, pBuffers);
		}
		if (m_pBindFlags[i] & BIND_HS) {
			m_pd3dDeviceContext->HSSetConstantBuffers(m_pSlots[i], 1, pBuffers);
		}
		if (m_pBindFlags[i] & BIND_GS) {
			m_pd3dDeviceContext->GSSetConstantBuffers(m_pSlots[i], 1, pBuffers);
		}
		if (m_pBindFlags[i] & BIND_PS) {
			m_pd3dDeviceContext->PSSetConstantBuffers(m_pSlots[i], 1, pBuffers);
		}
		if (m_pBindFlags[i] & BIND_CS) {
			m_pd3dDeviceContext->CSSetConstantBuffers(m_pSlots[i], 1, pBuffers);
		}
	}

}

void CConstantBuffer::UpdateShaderState(){

}





ID3D11Buffer* CConstantBuffer::CreateConstantBuffer(UINT nByteWidth){
	
	ID3D11Buffer* pd3dBuffer;
	D3D11_BUFFER_DESC d3dBufferDesc;
	ZeroMemory(&d3dBufferDesc, sizeof(D3D11_BUFFER_DESC));
	/*������ �ʱ�ȭ �����Ͱ� ������ ���� ���۷� �����Ѵ�. ��, ���߿� ������ �Ͽ� ������ ä��ų� �����Ѵ�.*/
	d3dBufferDesc.Usage = D3D11_USAGE_DYNAMIC;
	d3dBufferDesc.ByteWidth = nByteWidth;
	d3dBufferDesc.BindFlags = D3D11_BIND_CONSTANT_BUFFER;
	d3dBufferDesc.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE;
	
	//�ʱ�ȭ data ����!
	m_pd3dDevice->CreateBuffer(&d3dBufferDesc, NULL, &pd3dBuffer);

	return pd3dBuffer;
}


CConstantBuffer::CConstantBuffer(ID3D11Device* pd3dDevice, ID3D11DeviceContext* pd3dDeviceContext) : CBuffer(pd3dDevice, pd3dDeviceContext) { }
CConstantBuffer::~CConstantBuffer() { };

