#include "stdafx.h"
#include "InstanceBuffer.h"

bool CInstanceBuffer::Begin(int nBuffers, UINT* pObjects, UINT* pBufferStrides, UINT* pOffsets) {
	//setdata
	m_pnObjects = new UINT[nBuffers];
	m_pBufferStrides = new UINT[nBuffers];
	m_pByteWidths = new UINT[nBuffers];
	m_ppd3dBuffer = new ID3D11Buffer*[nBuffers];
	m_pOffsets = new UINT[nBuffers];
	m_pMappedData = new D3D11_MAPPED_SUBRESOURCE[nBuffers];
	m_ppData = new void*[nBuffers];

	m_nBuffers = nBuffers;
	for (int i = 0; i < m_nBuffers; ++i) {
		m_pnObjects[i] = pObjects[i];
		m_pBufferStrides[i] = pBufferStrides[i];
		m_pByteWidths[i] = m_pnObjects[i] * m_pBufferStrides[i];
		m_pOffsets[i] = pOffsets[i];
		//create buffer
		m_ppd3dBuffer[i] = CreateInstanceBuffer(m_pByteWidths[i]);
	}
	return true;
}

bool CInstanceBuffer::End() {

	if (m_pnObjects) delete[] m_pnObjects;
	if (m_pBufferStrides) delete[] m_pBufferStrides;
	if (m_pByteWidths) delete[] m_pByteWidths;
	if (m_ppd3dBuffer) delete[] m_ppd3dBuffer;
	if (m_pMappedData) delete[] m_pMappedData;
	if (m_ppData) delete[] m_ppData;

	return true;
}

//instance buffer�� set/ clean �׷��� ���ص� ��
void CInstanceBuffer::SetShaderState() {

}
void CInstanceBuffer::CleanShaderState() {

}

void CInstanceBuffer::UpdateShaderState() {

}


//�ʱ� ���� ���� instanceBuffer����
ID3D11Buffer* CInstanceBuffer::CreateInstanceBuffer(UINT nByteWidth) {

	ID3D11Buffer *pd3dInstanceBuffer = NULL;
	D3D11_BUFFER_DESC d3dBufferDesc;
	ZeroMemory(&d3dBufferDesc, sizeof(D3D11_BUFFER_DESC));
	/*������ �ʱ�ȭ �����Ͱ� ������ ���� ���۷� �����Ѵ�. ��, ���߿� ������ �Ͽ� ������ ä��ų� �����Ѵ�.*/
	d3dBufferDesc.Usage = D3D11_USAGE_DYNAMIC;
	d3dBufferDesc.ByteWidth = nByteWidth;
	d3dBufferDesc.BindFlags = D3D11_BIND_VERTEX_BUFFER;
	d3dBufferDesc.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE;
	D3D11_SUBRESOURCE_DATA d3dBufferData;
	m_pd3dDevice->CreateBuffer(&d3dBufferDesc, NULL, &pd3dInstanceBuffer);
	return(pd3dInstanceBuffer);

	return pd3dInstanceBuffer;
}


CInstanceBuffer::CInstanceBuffer(ID3D11Device* pd3dDevice, ID3D11DeviceContext* pd3dDeviceContext) : CBuffer(pd3dDevice, pd3dDeviceContext) { }
CInstanceBuffer::~CInstanceBuffer() { };

