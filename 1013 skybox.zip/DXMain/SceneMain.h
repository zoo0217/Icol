#pragma once

#include "Scene.h"
#include "DirectXFramework.h"

#include "LightLayer.h"
#include "ObjectLayer.h"
#include "PostProcessingLayer.h"

//object
#include "FreeCamera.h"
#include "ThirdPersonCamera.h"

#include "TestAnimateContainer.h"
//#include "TestDeferredRenderContainer.h"
//#include "PostProcessingRenderContainer.h"
#include "RenderContainerSeller.h"

#include "Player.h"

//object

//-------------------------deferred lighting------------------
#define RENDER_TARGET_NUMBER 3
//-------------------------deferred lighting------------------

class CSceneMain :public CScene{

public:
	//-----------------------------------scene--------------------------
	virtual bool Begin();
	virtual bool End();

	virtual void Animate(float fTimeElapsed);
	virtual void Render();

	virtual void OnProcessingMouseMessage(HWND hWnd, UINT nMessageID, WPARAM wParam, LPARAM lParam);
	virtual void OnProcessingKeyboardMessage(HWND hWnd, UINT nMessageID, WPARAM wParam, LPARAM lParam);
	virtual void ProcessInput(float fTimeElapsed);

private:
	//-----------------------------------scene--------------------------

	/*
		�������� �Ǿ��ִ� ������ ī�޶� ���������� ����Ͽ� �������� �ø��� �����Ѵ�.
		�˻�� space�� �ش� space�� leaf space���� ����
		scene�� �ִ� �Լ��� �ڽ��� animatecontainer�� �����Ѵ�. 
	*/
	
	void PrepareRenderContainer(CAnimateContainer* ac);
	//excute rendercontainer!
	void ExcuteRenderContainer();
	//rendercontainer clear
	void ClearRenderContainer();

	
private:
	CDirectXFramework* m_pFrameWork{ nullptr };

	//��¥ ī�޶�� framework�� �ִ�.
	shared_ptr<CCamera> m_pCamera{ nullptr };

	//skybox object
	CSkyBox* m_pSkyBox{ nullptr };

	//---------------------------container test -------------------------
	//CContainer* m_pContainer{ nullptr };
	//animate!
	CAnimateContainer* m_pAnimateContainer{ nullptr };
	//space���� ��� ��ü �ӽ� ���� �����̳�
	CAnimateContainer* m_pExcludeContainer{ nullptr };

	CRenderContainerSeller* m_RenderContainerSeller{ nullptr };

	//CPostProcessingRenderContainer* m_pPostProcessingRenderContainer{ nullptr };
	//CTestDeferredRenderContainer* m_pTestDeferredRenderContainer{ nullptr };

	//mapRenderContainer m_mRenderContainer;
	//mapLayer m_mLayer;
	CLightLayer* m_pLightLayer{ nullptr };
	CObjectLayer* m_pObjectLayer{ nullptr };
	CPostProcessingLayer* m_pPostProcessingLayer{ nullptr };
	//---------------------------container test -------------------------

	//-------------------------------player-------------------------------
	CPlayer* m_pPlayer{ nullptr };
	//-------------------------------player-------------------------------
	//input
	//���������� ���콺 ��ư�� Ŭ���� ���� ���콺 Ŀ���� ��ġ�̴�.
	POINT	m_ptOldCursorPos;

	//---------------------------d3ddevice & hWnd------------------------
	ID3D11Device* m_pd3dDevice{ nullptr };
	ID3D11DeviceContext* m_pd3dDeviceContext{ nullptr };
	HWND m_hWnd{ nullptr };
	//---------------------------d3ddevice & hWnd------------------------

	//---------------------------deferred rendering-----------------------
	ID3D11Texture2D			 *m_pd3dtxtColorSpecInt;//0
	ID3D11Texture2D			 *m_pd3dtxtNormal;//1
	ID3D11Texture2D			 *m_pd3dtxtSpecPow;//2

	ID3D11ShaderResourceView *m_pd3dsrvColorSpecInt;//0
	ID3D11ShaderResourceView *m_pd3dsrvNormal;//1
	ID3D11ShaderResourceView *m_pd3dsrvSpecPow;//2

	ID3D11RenderTargetView   *m_pd3drtvColorSpecInt;//0
	ID3D11RenderTargetView   *m_pd3drtvNormal;//1
	ID3D11RenderTargetView   *m_pd3drtvSpecPow;//2

	//--------------------------light render target----------------
	ID3D11Texture2D			 *m_pd3dtxtLight;
	ID3D11ShaderResourceView *m_pd3dsrvLight;
	ID3D11RenderTargetView   *m_pd3drtvLight;
	//--------------------------light render target----------------

	//-------------------------------sampler value---------------------
	UINT m_nDeferredSamplerStartSlot{ 0 };
	UINT m_nDeferredSampler{ 0 };
	ID3D11SamplerState* m_pDeferredSamplerState{ nullptr };
	//-------------------------------sampler value---------------------

	//-----------------------render func-------------------
	void ForwardRender();
	void DeferredRender();
	void PostProcessing();
	//-----------------------render func-------------------
	//----------------------create func--------------------
	void CreateRenderTargets();
	void ReleaseRenderTargets();
	void SetRenderTargets();
	//----------------------create func--------------------
	//---------------------------deferred rendering-----------------------
public:
	CSceneMain(CDirectXFramework* pFrameWork);
	~CSceneMain();
	

};