#include "stdafx.h"
#include "SceneMain.h"

bool CSceneMain::Begin() {

	//m_pPlayer = new CPlayer;
	//m_pPlayer->Begin();
	m_pCamera = m_pFrameWork->GetCamera();


	//--------------------------------�����̳� ����-----------------------
	m_RenderContainerSeller = new CRenderContainerSeller(m_pCamera, m_pd3dDevice, m_pd3dDeviceContext);
	m_RenderContainerSeller->Begin();

	
	//space�� �Ѿ ����
	m_pAnimateContainer = new CTestAnimateContainer(m_pd3dDevice, m_pd3dDeviceContext);
	m_pAnimateContainer->Begin(m_RenderContainerSeller);

	//skybox
	m_pSkyBox = new CSkyBox();
	m_pSkyBox->Begin();

	m_pSkyBox->SetRenderContainer(m_RenderContainerSeller);
	m_pSkyBox->SetCamera(m_pCamera);
	//skybox

	//���� �����̳� ����
	//--------------------------------�����̳� ����-----------------------
	
	//m_pCamera->SetPlayer(m_pPlayer);

	//-----------------------------deferred lighting-------------------------
	//create postprocessing rendercontainer & rendertargets
	CreateRenderTargets();
	//-----------------------------deferred lighting-------------------------
	
	return true;
}

bool CSceneMain::End() {
	//m_pPlayer->End();
	m_RenderContainerSeller->End();

	if (m_pAnimateContainer) {
		m_pAnimateContainer->End();
		delete m_pAnimateContainer;
	}

	ClearRenderContainer();

	if (m_pPostProcessingLayer) {
		m_pPostProcessingLayer->End();
		delete m_pPostProcessingLayer;
	}

	ReleaseRenderTargets();

	//ī�޶�� Framework�� �����ϴ� ���̱⿡ End()�۾��� �������� �ʴ´�.
	return true;
}

void CSceneMain::Animate(float fTimeElapsed) {
	
	//������ set
	float fAdaptationNorm;
	static float fAdaptation = 1.0f;
	static bool s_bFirstTime = true;
	if (s_bFirstTime)
	{
		// On the first frame we want to fully adapt the new value so use 0
		fAdaptationNorm = 0.0f;
		s_bFirstTime = false;
	}
	else
	{
		// Normalize the adaptation time with the frame time (all in seconds)
		// Never use a value higher or equal to 1 since that means no adaptation at all (keeps the old value)
		fAdaptationNorm = min(fAdaptation < 0.0001f ? 1.0f : fTimeElapsed / fAdaptation, 0.9999f);
	}
	m_pPostProcessingLayer->SetAdaptation(fAdaptationNorm);

	m_pAnimateContainer->Animate(fTimeElapsed, m_pExcludeContainer);

	//skybox camera ����ȭ
	m_pSkyBox->Animate(fTimeElapsed);
	m_pSkyBox->RegistToContainer();

	//m_pContainer->Animate(fTimeElapsed);
}
//----------------------------------deferred lighting--------------------------
void CSceneMain::CreateRenderTargets() {
	//--------------------------deferred light------------------------

	//----------------------------------------Resource Desc-----------------------------------------//
	D3D11_SHADER_RESOURCE_VIEW_DESC d3dSRVDesc;
	::ZeroMemory(&d3dSRVDesc, sizeof(D3D11_SHADER_RESOURCE_VIEW_DESC));
	d3dSRVDesc.ViewDimension = D3D11_SRV_DIMENSION_TEXTURE2D;
	d3dSRVDesc.Texture2D.MipLevels = 1;
	//d3dSRVDesc.Format = DXGI_FORMAT_R32_FLOAT;
	//----------------------------------------Resource Desc-----------------------------------------//
	//----------------------------------------TextUre Desc-----------------------------------------//
	D3D11_TEXTURE2D_DESC d3dTexture2DDesc;
	::ZeroMemory(&d3dTexture2DDesc, sizeof(D3D11_TEXTURE2D_DESC));
	d3dTexture2DDesc.Width = m_pFrameWork->GetDisplaySize().right;
	d3dTexture2DDesc.Height = m_pFrameWork->GetDisplaySize().bottom;
	d3dTexture2DDesc.MipLevels = 1;
	d3dTexture2DDesc.ArraySize = 1;
	d3dTexture2DDesc.SampleDesc.Count = 1;
	d3dTexture2DDesc.SampleDesc.Quality = 0;
	d3dTexture2DDesc.Usage = D3D11_USAGE_DEFAULT;
	d3dTexture2DDesc.CPUAccessFlags = 0;
	d3dTexture2DDesc.MiscFlags = 0;
	d3dTexture2DDesc.BindFlags = D3D11_BIND_RENDER_TARGET | D3D11_BIND_SHADER_RESOURCE;
	//d3dTexture2DDesc.Format = DXGI_FORMAT_R32_TYPELESS;
	//----------------------------------------TextUre Desc-----------------------------------------//
	//----------------------------------------Render Desc-----------------------------------------//
	D3D11_RENDER_TARGET_VIEW_DESC d3dRTVDesc;
	d3dRTVDesc.ViewDimension = D3D11_RTV_DIMENSION_TEXTURE2D;
	d3dRTVDesc.Texture2D.MipSlice = 0;
	//----------------------------------------TextUre Desc-----------------------------------------//
	d3dTexture2DDesc.Format = d3dSRVDesc.Format = d3dRTVDesc.Format = DXGI_FORMAT_R32G32B32A32_FLOAT;

	//--------------------------------------Scene0 RTV Create-----------------------------------------//
	m_pd3dDevice->CreateTexture2D(&d3dTexture2DDesc, nullptr, &m_pd3dtxtColorSpecInt);
	m_pd3dDevice->CreateShaderResourceView(m_pd3dtxtColorSpecInt, &d3dSRVDesc, &m_pd3dsrvColorSpecInt);
	m_pd3dDevice->CreateRenderTargetView(m_pd3dtxtColorSpecInt, &d3dRTVDesc, &m_pd3drtvColorSpecInt);
	//--------------------------------------Scene0 RTV Create-----------------------------------------//

	//--------------------------------------Scene1 RTV Create-----------------------------------------//
	m_pd3dDevice->CreateTexture2D(&d3dTexture2DDesc, nullptr, &m_pd3dtxtNormal);
	m_pd3dDevice->CreateRenderTargetView(m_pd3dtxtNormal, &d3dRTVDesc, &m_pd3drtvNormal);
	m_pd3dDevice->CreateShaderResourceView(m_pd3dtxtNormal, &d3dSRVDesc, &m_pd3dsrvNormal);
	//--------------------------------------Scene1 RTV Create-----------------------------------------//

	//--------------------------------------Scene2 RTV Create-----------------------------------------//
	m_pd3dDevice->CreateTexture2D(&d3dTexture2DDesc, nullptr, &m_pd3dtxtSpecPow);
	m_pd3dDevice->CreateRenderTargetView(m_pd3dtxtSpecPow, &d3dRTVDesc, &m_pd3drtvSpecPow);
	m_pd3dDevice->CreateShaderResourceView(m_pd3dtxtSpecPow, &d3dSRVDesc, &m_pd3dsrvSpecPow);
	//--------------------------------------Scene2 RTV Create-----------------------------------------//

	//--------------------------------------sampler state-------------------------------------
	m_nDeferredSamplerStartSlot = 0;
	m_nDeferredSampler = 1;
	D3D11_SAMPLER_DESC d3dSamplerDesc;
	ZeroMemory(&d3dSamplerDesc, sizeof(D3D11_SAMPLER_DESC));
	d3dSamplerDesc.AddressU = D3D11_TEXTURE_ADDRESS_CLAMP;
	d3dSamplerDesc.AddressV = D3D11_TEXTURE_ADDRESS_CLAMP;
	d3dSamplerDesc.AddressW = D3D11_TEXTURE_ADDRESS_CLAMP;
	d3dSamplerDesc.Filter = D3D11_FILTER_MIN_MAG_MIP_LINEAR;
	d3dSamplerDesc.ComparisonFunc = D3D11_COMPARISON_NEVER;
	d3dSamplerDesc.MinLOD = 0;
	d3dSamplerDesc.MaxLOD = 0;
	m_pd3dDevice->CreateSamplerState(&d3dSamplerDesc, &m_pDeferredSamplerState);
	//--------------------------------------sampler state-------------------------------------


	//�ڱ� texture set -> sampler set����
	shared_ptr<CTexture> pTexture = make_shared<CTexture>(m_pd3dDevice, m_pd3dDeviceContext);

	//---------------------make texture---------------------
	//texture set to light rendercontainer
	ID3D11ShaderResourceView *pd3dSRVs[RENDER_TARGET_NUMBER] = { m_pd3dsrvColorSpecInt, m_pd3dsrvNormal, m_pd3dsrvSpecPow };
	UINT pSlots[RENDER_TARGET_NUMBER] = { 0,1,2 };
	UINT pBindFlags[RENDER_TARGET_NUMBER] = { BIND_PS, BIND_PS ,BIND_PS };
	//make sampler
	shared_ptr<CSampler> pSampler = make_shared<CSampler>(m_pd3dDevice, m_pd3dDeviceContext);
	D3D11_TEXTURE_ADDRESS_MODE pMode[1] = { D3D11_TEXTURE_ADDRESS_CLAMP };
	D3D11_FILTER pFilter[1] = { D3D11_FILTER_MIN_MAG_MIP_LINEAR };
	D3D11_COMPARISON_FUNC pFunc[1] = { D3D11_COMPARISON_NEVER };
	float pMin[1] = { 0 };
	float pMax[1] = { 0 };
	UINT pSamplerBindFlags[1] = { BIND_PS };
	UINT pSamplerSlots[1] = { 0 };
	pSampler->Begin(1, pSamplerSlots, pMode, pFilter, pFunc, pMin, pMax, pSamplerBindFlags);

	pTexture->Begin(RENDER_TARGET_NUMBER, pSlots, pd3dSRVs, pBindFlags, pSampler, nullptr, false);
	//---------------------make texture---------------------

	//set texture
	//craete layer
	m_pLightLayer = new CLightLayer(m_pCamera, m_pd3dDevice, m_pd3dDeviceContext);
	m_pLightLayer->Begin(m_RenderContainerSeller, pTexture);

	m_pObjectLayer = new CObjectLayer(m_pCamera, m_pd3dDevice, m_pd3dDeviceContext);
	m_pObjectLayer->Begin(m_RenderContainerSeller);

	//m_mRenderContainer[object_id::OBJECT_LIGHT]->SetTexture(pTexture);
	//--------------------------deferred light------------------------

	//------------------------------light render target-----------------------
	
	//------------------------------light render target-----------------------
	m_pd3dDevice->CreateTexture2D(&d3dTexture2DDesc, nullptr, &m_pd3dtxtLight);
	m_pd3dDevice->CreateRenderTargetView(m_pd3dtxtLight, &d3dRTVDesc, &m_pd3drtvLight);
	m_pd3dDevice->CreateShaderResourceView(m_pd3dtxtLight, &d3dSRVDesc, &m_pd3dsrvLight);
	pTexture = make_shared<CTexture>(m_pd3dDevice, m_pd3dDeviceContext);

	//make texture
	UINT pLightTexSlots[1] = { 0 };
	UINT pLightTexBindFlags[1] = { BIND_PS | BIND_CS };
	//make sampler
	shared_ptr<CSampler> pLightTexSampler = make_shared<CSampler>(m_pd3dDevice, m_pd3dDeviceContext);
	D3D11_TEXTURE_ADDRESS_MODE pLightTexMode[1] = { D3D11_TEXTURE_ADDRESS_CLAMP };
	D3D11_FILTER pLightTexFilter[1] = { D3D11_FILTER_MIN_MAG_MIP_LINEAR };
	D3D11_COMPARISON_FUNC pLightTexFunc[1] = { D3D11_COMPARISON_NEVER };
	float pLightTexMin[1] = { 0 };
	float pLightTexMax[1] = { 0 };
	UINT pLightTexSamplerBindFlags[1] = { BIND_PS | BIND_CS };
	UINT pLightTexSamplerSlots[1] = { 0 };
	pLightTexSampler->Begin(1, pLightTexSamplerSlots, pLightTexMode, pLightTexFilter, pLightTexFunc, pLightTexMin, pLightTexMax, pLightTexSamplerBindFlags);

	pTexture->Begin(1, pLightTexSlots, &m_pd3dsrvLight, pLightTexBindFlags, pLightTexSampler, nullptr, false);
	
	m_pPostProcessingLayer = new CPostProcessingLayer(m_pCamera, m_pd3dDevice, m_pd3dDeviceContext);
	m_pPostProcessingLayer->Begin(m_RenderContainerSeller, pTexture);
	RECT CliensRect = m_pFrameWork->GetDisplaySize();
	//first pass data set
	m_pPostProcessingLayer->SetFirstPassData(CliensRect.right, CliensRect.bottom);
	m_pPostProcessingLayer->SetBloomThreshold(2.0f);
	float fMiddleGrey = 0.0025f;
	float fWhite = 1.5f;
	float fBloomScale = 0.1f;
	m_pPostProcessingLayer->SetFinalPassData(fMiddleGrey, fWhite, fBloomScale);
	//------------------------------light render target-----------------------

}
void CSceneMain::SetRenderTargets() {
	ID3D11RenderTargetView *pd3dRTVs[RENDER_TARGET_NUMBER] = { m_pd3drtvColorSpecInt, m_pd3drtvNormal, m_pd3drtvSpecPow };
	float fClearColor[4] = { 0.0f, 0.0f, 0.0f, 1.0f };
	if (m_pd3drtvColorSpecInt) m_pd3dDeviceContext->ClearRenderTargetView(m_pd3drtvColorSpecInt, fClearColor);
	if (m_pd3drtvNormal) m_pd3dDeviceContext->ClearRenderTargetView(m_pd3drtvNormal, fClearColor);
	if (m_pd3drtvSpecPow) m_pd3dDeviceContext->ClearRenderTargetView(m_pd3drtvSpecPow, fClearColor);

	m_pFrameWork->SetRenderTargetViews(RENDER_TARGET_NUMBER, pd3dRTVs);

	//m_pFrameWork->SetMainRenderTargetView();

	//multi thread rendering 
	//for (auto &pRenderThreadInfo : m_vRenderingThreadInfo)
	//{
	//	pRenderThreadInfo.m_pd3dDeferredContext->OMSetRenderTargets(MULITE_RENDER_NUMBER, (ID3D11RenderTargetView **)&pd3dRTVs, m_pd3dDepthStencilView);
	//	::SetEvent(pRenderThreadInfo.m_hRenderingBeginEvent);
	//}
}
void CSceneMain::ForwardRender() {

	m_pFrameWork->ClearDepthStencilView();

	//set 4 render target view 
	SetRenderTargets();

	PrepareRenderContainer(m_pAnimateContainer);

	ExcuteRenderContainer();

}
void CSceneMain::DeferredRender() {
	//����Ÿ�� �� ����
	
	//clear depthStencilview�� ���� ����
	m_pFrameWork->ClearDepthStencilView();

	//set light rtv
	m_pFrameWork->SetRenderTargetViews(1, &m_pd3drtvLight);
	//render light!
	m_pLightLayer->Render();

	//all rendercontianer clear!
	ClearRenderContainer();

}
void CSceneMain::PostProcessing() {
	//clear depthStencilview�� ���� ����
	m_pFrameWork->ClearDepthStencilView();

	//��¥ rtv set!
	//m_pFrameWork->ClearRenderTargetView();
	m_pFrameWork->SetMainRenderTargetView();

	//rtv�� Ǯ��ũ�� ��ο� 
	m_pPostProcessingLayer->Render();

	
}
void CSceneMain::ReleaseRenderTargets() {
	if(m_pd3dtxtColorSpecInt) m_pd3dtxtColorSpecInt->Release();//0
	m_pd3dtxtColorSpecInt = nullptr;

	if(m_pd3dtxtNormal) m_pd3dtxtNormal->Release();//1
	m_pd3dtxtNormal = nullptr;

	if(m_pd3dtxtSpecPow) m_pd3dtxtSpecPow->Release();//2
	m_pd3dtxtSpecPow = nullptr;

	if(m_pd3dsrvColorSpecInt) m_pd3dsrvColorSpecInt->Release();//0
	m_pd3dsrvColorSpecInt = nullptr;

	if(m_pd3dsrvNormal) m_pd3dsrvNormal->Release();//1
	m_pd3dsrvNormal = nullptr;

	if (m_pd3dsrvSpecPow) m_pd3dsrvSpecPow->Release();//2
	m_pd3dsrvSpecPow = nullptr;

	if(m_pd3drtvColorSpecInt) m_pd3drtvColorSpecInt->Release();//0
	m_pd3drtvColorSpecInt = nullptr;

	if(m_pd3drtvNormal) m_pd3drtvNormal->Release();//1
	m_pd3drtvNormal = nullptr;

	if(m_pd3drtvSpecPow) m_pd3drtvSpecPow->Release();//2
	m_pd3drtvSpecPow = nullptr;

	if (m_pd3drtvLight) m_pd3drtvLight->Release();
	m_pd3drtvLight = nullptr;

}

void CSceneMain::Render() {
	ForwardRender();
	DeferredRender();
	PostProcessing();
}

void CSceneMain::OnProcessingMouseMessage(HWND hWnd, UINT nMessageID, WPARAM wParam, LPARAM lParam) {
	switch (nMessageID)
	{
	case WM_LBUTTONDOWN:
	case WM_RBUTTONDOWN:
		//���콺 ĸ�ĸ� �ϰ� ���� ���콺 ��ġ�� �����´�.
		SetCapture(hWnd);
		GetCursorPos(&m_ptOldCursorPos);
		break;
	case WM_LBUTTONUP:
	case WM_RBUTTONUP:
		//���콺 ĸ�ĸ� �����Ѵ�.
		ReleaseCapture();
		break;

	case WM_MOUSEMOVE:
		break;
	default:
		break;
	}
}
void CSceneMain::OnProcessingKeyboardMessage(HWND hWnd, UINT nMessageID, WPARAM wParam, LPARAM lParam) {

	switch (nMessageID)
	{
	case WM_KEYUP:
		switch (wParam)
		{
		case VK_F1:
		case VK_F2:
		case VK_F3:
			break;
		default:
			break;
		}
		break;
	default:
		break;
	}
}

void CSceneMain::ProcessInput(float fTimeElapsed) {
	bool bProcessedByScene = false;
	static UCHAR pKeyBuffer[256];
	float cxDelta = 0.0f, cyDelta = 0.0f;

	//if (m_pScene) bProcessedByScene = m_pScene->ProcessInput();
	if (!bProcessedByScene)
	{
		POINT ptCursorPos;
		//���콺�� ĸ�������� ���콺�� �󸶸�ŭ �̵��Ͽ��� ���� ����Ѵ�.
		if (GetCapture() == m_hWnd)
		{
			//���콺 Ŀ���� ȭ�鿡�� ���ش�(������ �ʰ� �Ѵ�).
			SetCursor(NULL);
			//���� ���콺 Ŀ���� ��ġ�� �����´�.
			GetCursorPos(&ptCursorPos);
			//���콺 ��ư�� ���� ä�� ���� ��ġ���� ���� ���콺 Ŀ���� ��ġ���� ������ ���� ���Ѵ�.
			cxDelta = (float)(ptCursorPos.x - m_ptOldCursorPos.x) / 3.0f;
			cyDelta = (float)(ptCursorPos.y - m_ptOldCursorPos.y) / 3.0f;
			SetCursorPos(m_ptOldCursorPos.x, m_ptOldCursorPos.y);
		}

		//Ű�Է� �Ǵ� ���콺 �������� �־��ٸ� 
		if (GetKeyboardState(pKeyBuffer) || cxDelta || cyDelta)
		{
			m_pCamera->ProcessInput(fTimeElapsed, pKeyBuffer, cxDelta, cyDelta);
			//-----------------------------------player--------------------------------------
			//m_pPlayer->ProcessInput(fTimeElapsed, pKeyBuffer, cxDelta, cyDelta);
			//-----------------------------------player--------------------------------------
		}

	}

	
}

void CSceneMain::PrepareRenderContainer(CAnimateContainer* ac) {
	//animatecontainer���� object list�� ������ �´�.
	list<CObject*> plObject = ac->GetObjectList();
	//list�� ��� object�� id�� �´� RenderContainer���� �����Ѵ�. 

	
	for (auto pObject : plObject) {
		pObject->RegistToContainer();
	}

	//-----------------------------------------player-------------------------------
	//m_mRenderContainer[m_pPlayer->GetControlObject()->GetObjectID()]->AddObject(m_pPlayer->GetControlObject());
	//-----------------------------------------player-------------------------------

}
void CSceneMain::ExcuteRenderContainer() {
	//scene�� ��� ��ü�� rendercontainer�ȿ� object list clear!
	//scene�� ��� ��ü�� rendercontainer�ȿ� object list clear!

	m_pObjectLayer->Render();

	
}
void CSceneMain::ClearRenderContainer() {
	
}

CSceneMain::CSceneMain(CDirectXFramework* pFrameWork) : CScene("Main") {
	m_pFrameWork = pFrameWork;
	m_pd3dDevice = m_pFrameWork->GetDevice();
	m_pd3dDeviceContext = m_pFrameWork->GetDeviceContext();
	m_hWnd = m_pFrameWork->GethWnd();

	m_pd3dtxtColorSpecInt = nullptr;
	m_pd3dtxtNormal = nullptr;
	m_pd3dtxtSpecPow = nullptr;

	m_pd3dsrvColorSpecInt = nullptr;
	m_pd3dsrvNormal = nullptr;
	m_pd3dsrvSpecPow = nullptr;

	m_pd3drtvColorSpecInt= nullptr;
	m_pd3drtvNormal = nullptr;
	m_pd3drtvSpecPow = nullptr;

}
CSceneMain::~CSceneMain() {

}


