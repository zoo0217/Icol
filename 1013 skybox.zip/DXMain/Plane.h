#pragma once
#include "Object.h"
#include "RotateComponent.h"

class CPlane : public CObject {

public:
	//----------------------------dxobject-----------------------------
	bool Begin();
	virtual bool End();
	//----------------------------dxobject-----------------------------

private:


public:
	CPlane();
	~CPlane();
};
