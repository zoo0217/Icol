#pragma once
#include "Object.h"
#include "Camera.h"

class CSkyBox : public CObject {

public:
	//----------------------------dxobject-----------------------------
	bool Begin();
	virtual bool End();
	//----------------------------dxobject-----------------------------

	//object
	virtual void Animate(float fTimeElapsed);

	//skybox
	void SetCamera(shared_ptr<CCamera> pCamera);
private:
	shared_ptr<CCamera> m_pCamera;

public:
	CSkyBox();
	~CSkyBox();
};
