#include "stdafx.h"
#include "RenderContainerSeller.h"

bool CRenderContainerSeller::Begin()
{
	//core render shader
	m_pCoreShader = make_shared<CRenderShader>(m_pd3dDevice, m_pd3dDeviceContext);
	D3D11_INPUT_ELEMENT_DESC vertexDesc[] =
	{
		{ "POSITION", 0, DXGI_FORMAT_R32G32B32_FLOAT, 0, 0, D3D11_INPUT_PER_VERTEX_DATA, 0 },//model
		{ "NORMAL", 0, DXGI_FORMAT_R32G32B32_FLOAT, 1, 0, D3D11_INPUT_PER_VERTEX_DATA, 0 },//color
		{ "TEXCOORD", 0, DXGI_FORMAT_R32G32_FLOAT, 2, 0, D3D11_INPUT_PER_VERTEX_DATA, 0 },//uv
		{ "INSTANCEPOS", 0, DXGI_FORMAT_R32G32B32A32_FLOAT, 3, 0, D3D11_INPUT_PER_INSTANCE_DATA, 1 },
		{ "INSTANCEPOS", 1, DXGI_FORMAT_R32G32B32A32_FLOAT, 3, D3D11_APPEND_ALIGNED_ELEMENT, D3D11_INPUT_PER_INSTANCE_DATA, 1 },
		{ "INSTANCEPOS", 2, DXGI_FORMAT_R32G32B32A32_FLOAT, 3, D3D11_APPEND_ALIGNED_ELEMENT, D3D11_INPUT_PER_INSTANCE_DATA, 1 },
		{ "INSTANCEPOS", 3, DXGI_FORMAT_R32G32B32A32_FLOAT, 3, D3D11_APPEND_ALIGNED_ELEMENT, D3D11_INPUT_PER_INSTANCE_DATA, 1 },
	};
	m_pCoreShader->CreateVS(TEXT("VertexShader.cso"), vertexDesc, 7);
	m_pCoreShader->CreatePS(TEXT("PixelShader.cso"));
	m_pCoreShader->Begin();
	//core render shader
	//light shader
	m_pDirectionalLightShader = make_shared<CRenderShader>(m_pd3dDevice, m_pd3dDeviceContext);
	m_pDirectionalLightShader->CreateVS(TEXT("VSDirectionalLight.cso"));
	m_pDirectionalLightShader->CreatePS(TEXT("PSDirectionalLight.cso"));
	m_pDirectionalLightShader->Begin();

	m_pPointLightShader = make_shared<CRenderShader>(m_pd3dDevice, m_pd3dDeviceContext);
	m_pPointLightShader->CreateVS(TEXT("VSPointLight.cso"));
	m_pPointLightShader->CreateHS(TEXT("HSPointLight.cso"));
	m_pPointLightShader->CreateDS(TEXT("DSPointLight.cso"));
	m_pPointLightShader->CreatePS(TEXT("PSPointLight.cso"));
	m_pPointLightShader->Begin();

	m_pSpotLightShader = make_shared<CRenderShader>(m_pd3dDevice, m_pd3dDeviceContext);
	m_pSpotLightShader->CreateVS(TEXT("VSSpotLight.cso"));
	m_pSpotLightShader->CreateHS(TEXT("HSSpotLight.cso"));
	m_pSpotLightShader->CreateDS(TEXT("DSSpotLight.cso"));
	m_pSpotLightShader->CreatePS(TEXT("PSSpotLight.cso"));
	m_pSpotLightShader->Begin();

	m_pCapsuleLightShader = make_shared<CRenderShader>(m_pd3dDevice, m_pd3dDeviceContext);
	m_pCapsuleLightShader->CreateVS(TEXT("VSCapsuleLight.cso"));
	m_pCapsuleLightShader->CreateHS(TEXT("HSCapsuleLight.cso"));
	m_pCapsuleLightShader->CreateDS(TEXT("DSCapsuleLight.cso"));
	m_pCapsuleLightShader->CreatePS(TEXT("PSCapsuleLight.cso"));
	m_pCapsuleLightShader->Begin();
	//light shader
	//post processing shader
	m_pPostProcessingShader = make_shared<CRenderShader>(m_pd3dDevice, m_pd3dDeviceContext);
	D3D11_INPUT_ELEMENT_DESC PostProcessingvertexDesc[] =
	{
		{ "POSITION", 0, DXGI_FORMAT_R32G32B32_FLOAT, 0, 0, D3D11_INPUT_PER_VERTEX_DATA, 0 },
		{ "TEXCOORD", 0, DXGI_FORMAT_R32G32_FLOAT, 1, 0, D3D11_INPUT_PER_VERTEX_DATA, 0 }
	};
	m_pPostProcessingShader->CreateVS(TEXT("VSPostProcessing.cso"), PostProcessingvertexDesc, 2);
	m_pPostProcessingShader->CreatePS(TEXT("PSPostProcessing.cso"));
	m_pPostProcessingShader->Begin();
	//post processing shader


	//material
	m_pCoreMaterial = make_shared<CMaterial>(m_pd3dDevice, m_pd3dDeviceContext);
	m_pCoreMaterial->Begin(XMFLOAT4(0.5, 0.1, 0.1, 1.0), 4, 1);

	m_pBoostMaterial = make_shared<CMaterial>(m_pd3dDevice, m_pd3dDeviceContext);
	m_pBoostMaterial->Begin(XMFLOAT4(0.1, 0.6, 0.6, 1.0), 4, 1);

	m_pWeaponMaterial = make_shared<CMaterial>(m_pd3dDevice, m_pd3dDeviceContext);
	m_pWeaponMaterial->Begin(XMFLOAT4(0.1, 0.7, 0.0, 1.0), 4, 1);

	m_pAdaptorMaterial = make_shared<CMaterial>(m_pd3dDevice, m_pd3dDeviceContext);
	m_pAdaptorMaterial->Begin(XMFLOAT4(0.6, 0.5, 0.1, 1.0), 4, 1);

	m_pPlaneMaterial = make_shared<CMaterial>(m_pd3dDevice, m_pd3dDeviceContext);
	m_pPlaneMaterial->Begin(XMFLOAT4(0.5, 0.5, 0.0, 1.0), 8, 2);
	//material

	//mesh
	m_pTestRectMesh1 = make_shared<CTestMesh>(m_pd3dDevice, m_pd3dDeviceContext);
	m_pTestRectMesh1->Begin();
	m_pTestRectMesh2 = make_shared<CTestMesh>(m_pd3dDevice, m_pd3dDeviceContext);
	m_pTestRectMesh2->Begin();
	m_pTestRectMesh3 = make_shared<CTestMesh>(m_pd3dDevice, m_pd3dDeviceContext);
	m_pTestRectMesh3->Begin();
	m_pTestRectMesh4 = make_shared<CTestMesh>(m_pd3dDevice, m_pd3dDeviceContext);
	m_pTestRectMesh4->Begin();
	m_pTestRectMesh5 = make_shared<CTestMesh>(m_pd3dDevice, m_pd3dDeviceContext);
	m_pTestRectMesh5->Begin();
	m_pPlaneMesh = make_shared<CPlaneMesh>(m_pd3dDevice, m_pd3dDeviceContext);
	m_pPlaneMesh->Begin();
	m_pDirectionalLightMesh = make_shared<CDirectionalLightMesh>(m_pd3dDevice, m_pd3dDeviceContext);
	m_pDirectionalLightMesh->Begin();
	m_pPointLightMesh = make_shared<CPointLightMesh>(m_pd3dDevice, m_pd3dDeviceContext);
	m_pPointLightMesh->Begin();
	m_pSpotLightMesh = make_shared<CSpotLightMesh>(m_pd3dDevice, m_pd3dDeviceContext);
	m_pSpotLightMesh->Begin();
	m_pCapsuleLightMesh = make_shared<CCapsuleLightMesh>(m_pd3dDevice, m_pd3dDeviceContext);
	m_pCapsuleLightMesh->Begin();
	m_pPostProcessingMesh = make_shared<CTestDeferredMesh>(m_pd3dDevice, m_pd3dDeviceContext);
	m_pPostProcessingMesh->Begin();
	//mesh

	//instance buffer
	UINT pBufferStrides[1] = { sizeof(VS_VB_INSTANCE) };
	UINT pObjects[1] = { m_nMaxNormalObjects };
	UINT pOffsets[1] = { 0 };
	m_pNormalInstanceBuffer1 = make_shared<CInstanceBuffer>(m_pd3dDevice, m_pd3dDeviceContext);
	m_pNormalInstanceBuffer1->Begin(1, pObjects, pBufferStrides, pOffsets);
	m_pNormalInstanceBuffer2 = make_shared<CInstanceBuffer>(m_pd3dDevice, m_pd3dDeviceContext);
	m_pNormalInstanceBuffer2->Begin(1, pObjects, pBufferStrides, pOffsets);
	m_pNormalInstanceBuffer3 = make_shared<CInstanceBuffer>(m_pd3dDevice, m_pd3dDeviceContext);
	m_pNormalInstanceBuffer3->Begin(1, pObjects, pBufferStrides, pOffsets);
	m_pNormalInstanceBuffer4 = make_shared<CInstanceBuffer>(m_pd3dDevice, m_pd3dDeviceContext);
	m_pNormalInstanceBuffer4->Begin(1, pObjects, pBufferStrides, pOffsets);
	pObjects[0] = { 10 };
	m_pNormalInstanceBuffer5 = make_shared<CInstanceBuffer>(m_pd3dDevice, m_pd3dDeviceContext);
	m_pNormalInstanceBuffer5->Begin(1, pObjects, pBufferStrides, pOffsets);
	pObjects[0] = { 1 };
	m_pPlaneInstanceBuffer = make_shared<CInstanceBuffer>(m_pd3dDevice, m_pd3dDeviceContext);
	m_pPlaneInstanceBuffer->Begin(1, pObjects, pBufferStrides, pOffsets);
	//instance buffer

	//light buffer
	m_pDirectionalLightBuffer = make_shared<CConstantBuffer>(m_pd3dDevice, m_pd3dDeviceContext);
	UINT pSlot[1] = { PS_OBJECT_BUFFER_SLOT };
	UINT pBindFlags[1] = { BIND_PS };
	pBufferStrides[0] = { sizeof(DIRECTIONAL_AMBIENT_LIGHT) };
	pObjects[0] = { 1 };
	pOffsets[0] = { 0 };
	m_pDirectionalLightBuffer->Begin(1, pSlot, pObjects, pBufferStrides, pBindFlags, pOffsets);

	m_pPointLightBuffer = make_shared<CConstantBuffer>(m_pd3dDevice, m_pd3dDeviceContext);
	UINT pPointSlot[2] = { DS_OBJECT_BUFFER_SLOT, PS_OBJECT_BUFFER_SLOT };
	UINT pPointBufferStrides[2] = { sizeof(POINT_LIGHT_DS_CB), sizeof(POINT_LIGHT_PS_CB) };
	UINT pPointBindFlags[2] = { BIND_DS, BIND_PS };
	UINT pPointObjects[2] = { 100, 100 };
	UINT pPointOffsets[2] = { 0, 0 };
	m_pPointLightBuffer->Begin(2, pPointSlot, pPointObjects, pPointBufferStrides, pPointBindFlags, pPointOffsets);

	m_pSpotLightBuffer = make_shared<CConstantBuffer>(m_pd3dDevice, m_pd3dDeviceContext);
	UINT pSpotSlot[2] = { DS_OBJECT_BUFFER_SLOT, PS_OBJECT_BUFFER_SLOT };
	UINT pSpotBufferStrides[2] = { sizeof(SPOT_LIGHT_DS_CB), sizeof(SPOT_LIGHT_PS_CB) };
	UINT pSpotBindFlags[2] = { BIND_DS, BIND_PS };
	UINT pSpotObjects[2] = { 100, 100 };
	UINT pSpotOffsets[2] = { 0, 0 };
	m_pSpotLightBuffer->Begin(2, pSpotSlot, pSpotObjects, pSpotBufferStrides, pSpotBindFlags, pSpotOffsets);

	m_pCapsuleLightBuffer = make_shared<CConstantBuffer>(m_pd3dDevice, m_pd3dDeviceContext);
	UINT pCapsuleSlot[2] = { DS_OBJECT_BUFFER_SLOT, PS_OBJECT_BUFFER_SLOT };
	UINT pCapsuleBufferStrides[2] = { sizeof(CAPSULE_LIGHT_DS_CB) , sizeof(CAPSULE_LIGHT_PS_CB) };
	UINT pCapsuleBindFlags[2] = { BIND_DS, BIND_PS };
	UINT pCapsuleObjects[2] = { 100, 100 };
	UINT pCapsuleOffsets[2] = { 0, 0 };

	m_pCapsuleLightBuffer->Begin(2, pCapsuleSlot, pCapsuleObjects, pCapsuleBufferStrides, pCapsuleBindFlags, pCapsuleOffsets);

	//SKYBOX
	//shader
	m_pSkyBoxShader = make_shared<CRenderShader>(m_pd3dDevice, m_pd3dDeviceContext);
	D3D11_INPUT_ELEMENT_DESC skyboxVertexDesc[] =
	{
		{ "POSITION", 0, DXGI_FORMAT_R32G32B32_FLOAT, 0, 0, D3D11_INPUT_PER_VERTEX_DATA, 0 },
		{ "TEXCOORD", 0, DXGI_FORMAT_R32G32_FLOAT, 1, 0, D3D11_INPUT_PER_VERTEX_DATA, 0 },
		{ "INSTANCEPOS", 0, DXGI_FORMAT_R32G32B32A32_FLOAT, 2, 0, D3D11_INPUT_PER_INSTANCE_DATA, 1 },
		{ "INSTANCEPOS", 1, DXGI_FORMAT_R32G32B32A32_FLOAT, 2, D3D11_APPEND_ALIGNED_ELEMENT, D3D11_INPUT_PER_INSTANCE_DATA, 1 },
		{ "INSTANCEPOS", 2, DXGI_FORMAT_R32G32B32A32_FLOAT, 2, D3D11_APPEND_ALIGNED_ELEMENT, D3D11_INPUT_PER_INSTANCE_DATA, 1 },
		{ "INSTANCEPOS", 3, DXGI_FORMAT_R32G32B32A32_FLOAT, 2, D3D11_APPEND_ALIGNED_ELEMENT, D3D11_INPUT_PER_INSTANCE_DATA, 1 },
		
		
	};
	//m_pSkyBoxShader->CreateVS(TEXT("VertexShader.cso"), skyboxVertexDesc, 6);
	//m_pSkyBoxShader->CreatePS(TEXT("PixelShader.cso"));
	m_pSkyBoxShader->CreateVS(TEXT("VSSkyBox.cso"), skyboxVertexDesc, 6);
	m_pSkyBoxShader->CreatePS(TEXT("PSSkyBox.cso"));
	//material
	m_pSkyBoxMaterial = make_shared<CMaterial>(m_pd3dDevice, m_pd3dDeviceContext);
	m_pSkyBoxMaterial->Begin(XMFLOAT4(1.0, 1.0, 1.0, 1.0), 1, 1);
	//skybox
	m_pSkyBoxMesh = make_shared<CSkyBoxMesh>(m_pd3dDevice, m_pd3dDeviceContext);
	m_pSkyBoxMesh->Begin();
	//buffer
	m_pSkyBoxBuffer = make_shared<CInstanceBuffer>(m_pd3dDevice, m_pd3dDeviceContext);
	UINT pSkyBoxBufferStrides[1] = { sizeof(VS_VB_INSTANCE) };
	UINT pSkyBoxObjects[1] = { 1 };
	UINT pSkyBoxOffsets[1] = { 0 };
	m_pSkyBoxBuffer->Begin(1, pSkyBoxObjects, pSkyBoxBufferStrides, pSkyBoxOffsets);

	//texture
	int nIndex = 0;
	_TCHAR pstrTextureNames[128];
	_stprintf_s(pstrTextureNames, _T("SkyBox_%d.dds"), nIndex, 128);
	ID3D11ShaderResourceView *pd3dsrvTexture = NULL;
	D3DX11CreateShaderResourceViewFromFile(m_pd3dDevice, pstrTextureNames, NULL, NULL, &pd3dsrvTexture, NULL);
	m_pSkyBoxTexture = make_shared<CTexture>(m_pd3dDevice, m_pd3dDeviceContext);
	ID3D11ShaderResourceView *pd3dSRVs[1] = { pd3dsrvTexture };
	UINT pSkyBoxSlots[1] = { PS_SLOT_SKYBOX };
	UINT pSkyBoxBindFlags[1] = { BIND_PS };
	//make sampler
	m_pSkyBoxSampler = make_shared<CSampler>(m_pd3dDevice, m_pd3dDeviceContext);
	D3D11_TEXTURE_ADDRESS_MODE pMode[1] = { D3D11_TEXTURE_ADDRESS_CLAMP };
	D3D11_FILTER pFilter[1] = { D3D11_FILTER_MIN_MAG_MIP_LINEAR };
	D3D11_COMPARISON_FUNC pFunc[1] = { D3D11_COMPARISON_NEVER };
	float pMin[1] = { 0 };
	float pMax[1] = { 0 };
	UINT pSamplerBindFlags[1] = { BIND_PS };
	UINT pSamplerSlots[1] = { 0 };
	m_pSkyBoxSampler->Begin(1, pSamplerSlots, pMode, pFilter, pFunc, pMin, pMax, pSamplerBindFlags);

	m_pSkyBoxTexture->Begin(1, pSkyBoxSlots, pd3dSRVs, pSkyBoxBindFlags, m_pSkyBoxSampler, nullptr, false);
	return true;
}

bool CRenderContainerSeller::End()
{
	//for (auto RenderContainer : m_mRenderContainer) {
	//	RenderContainer.second->End();
	//	delete RenderContainer.second;
	//}
	//m_mRenderContainer.clear();

	//shader
	m_pCoreShader->End();
	m_pDirectionalLightShader->End();
	m_pPointLightShader->End();
	m_pSpotLightShader->End();
	m_pCapsuleLightShader->End();


	//material
	m_pCoreMaterial->End();
	m_pBoostMaterial->End();
	m_pWeaponMaterial->End();
	m_pAdaptorMaterial->End();

	//mesh
	m_pTestRectMesh1->End();
	m_pTestRectMesh2->End();
	m_pTestRectMesh3->End();
	m_pTestRectMesh4->End();
	m_pTestRectMesh5->End();
	m_pPlaneMesh->End();
	m_pDirectionalLightMesh->End();
	m_pPointLightMesh->End();
	m_pSpotLightMesh->End();
	m_pCapsuleLightMesh->End();


	//constant bufer
	m_pNormalInstanceBuffer1->End();
	m_pNormalInstanceBuffer2->End();
	m_pNormalInstanceBuffer3->End();
	m_pNormalInstanceBuffer4->End();
	m_pNormalInstanceBuffer5->End();
	m_pPlaneInstanceBuffer->End();
	m_pDirectionalLightBuffer->End();
	m_pPointLightBuffer->End();
	m_pSpotLightBuffer->End();
	m_pCapsuleLightBuffer->End();

	//skybox
	m_pSkyBoxBuffer->End();
	m_pSkyBoxMaterial->End();
	m_pSkyBoxMesh->End();
	m_pSkyBoxSampler->End();
	m_pSkyBoxShader->End();
	m_pSkyBoxTexture->End();

	return true;
}

CRenderContainer* CRenderContainerSeller::GetRenderContainer(object_id objectid) {
	//CRenderContainer* pContainer{ nullptr };
	//int nMaxObjects{ 0 };

	//������ �ٷ� return
	if (m_mRenderContainer[objectid]) return m_mRenderContainer[objectid];

	//�����Ǹ� ���� ���� + container factory �ϳ� �� ����
	switch (objectid) {
	case object_id::OBJECT_TEST:
		m_mRenderContainer[objectid] = new CRenderContainer(m_pCamera, m_pd3dDevice, m_pd3dDeviceContext);

		m_mRenderContainer[objectid]->SetShader(m_pCoreShader);
		m_mRenderContainer[objectid]->SetMesh(m_pTestRectMesh5);
		m_mRenderContainer[objectid]->SetMaterial(m_pCoreMaterial);
		m_mRenderContainer[objectid]->SetInstanceBuffer(m_pNormalInstanceBuffer5);

		m_mRenderContainer[objectid]->Begin();

		//pContainer->CreateSharedBuffer(nMaxObjects, sizeof(VS_VB_INSTANCE));
		break;
	case object_id::OBJECT_CORE:
		m_mRenderContainer[objectid] = new CRenderContainer(m_pCamera, m_pd3dDevice, m_pd3dDeviceContext);

		m_mRenderContainer[objectid]->SetMesh(m_pTestRectMesh1);//mesh set�� ���ÿ� instancing buffer ���� �� set
		m_mRenderContainer[objectid]->SetShader(m_pCoreShader);
		m_mRenderContainer[objectid]->SetMaterial(m_pCoreMaterial);
		m_mRenderContainer[objectid]->SetInstanceBuffer(m_pNormalInstanceBuffer1);

		m_mRenderContainer[objectid]->Begin();
		break;
	case object_id::OBJECT_BOOST:
		//boost
		m_mRenderContainer[objectid] = new CRenderContainer(m_pCamera, m_pd3dDevice, m_pd3dDeviceContext);

		m_mRenderContainer[objectid]->SetMesh(m_pTestRectMesh2);//mesh set�� ���ÿ� instancing buffer ���� �� set
		m_mRenderContainer[objectid]->SetShader(m_pCoreShader);
		m_mRenderContainer[objectid]->SetMaterial(m_pBoostMaterial);
		m_mRenderContainer[objectid]->SetInstanceBuffer(m_pNormalInstanceBuffer2);
		m_mRenderContainer[objectid]->Begin();

		break;
	case object_id::OBJECT_WEAPON:
		//weapon
		m_mRenderContainer[objectid] = new CRenderContainer(m_pCamera, m_pd3dDevice, m_pd3dDeviceContext);

		m_mRenderContainer[objectid]->SetMesh(m_pTestRectMesh3);//mesh set�� ���ÿ� instancing buffer ���� �� set
		m_mRenderContainer[objectid]->SetShader(m_pCoreShader);
		m_mRenderContainer[objectid]->SetMaterial(m_pWeaponMaterial);
		m_mRenderContainer[objectid]->SetInstanceBuffer(m_pNormalInstanceBuffer3);

		m_mRenderContainer[objectid]->Begin();
		break;
	case object_id::OBJECT_ADAPTOR:
		//adaptor
		m_mRenderContainer[objectid] = new CRenderContainer(m_pCamera, m_pd3dDevice, m_pd3dDeviceContext);

		m_mRenderContainer[objectid]->SetMesh(m_pTestRectMesh4);//mesh set�� ���ÿ� instancing buffer ���� �� set
		m_mRenderContainer[objectid]->SetShader(m_pCoreShader);
		m_mRenderContainer[objectid]->SetMaterial(m_pAdaptorMaterial);
		m_mRenderContainer[objectid]->SetInstanceBuffer(m_pNormalInstanceBuffer4);

		m_mRenderContainer[objectid]->Begin();

		break;
	case object_id::OBJECT_PLANE:
		m_mRenderContainer[objectid] = new CRenderContainer(m_pCamera, m_pd3dDevice, m_pd3dDeviceContext);

		m_mRenderContainer[objectid]->SetMesh(m_pPlaneMesh);//mesh set�� ���ÿ� instancing buffer ���� �� set
		m_mRenderContainer[objectid]->SetShader(m_pCoreShader);
		m_mRenderContainer[objectid]->SetMaterial(m_pPlaneMaterial);
		m_mRenderContainer[objectid]->SetInstanceBuffer(m_pPlaneInstanceBuffer);

		m_mRenderContainer[objectid]->Begin();
		break;
	case object_id::OBJECT_DIRECTIONAL_LIGHT:
		m_mRenderContainer[objectid] = new CRenderContainer(m_pCamera, m_pd3dDevice, m_pd3dDeviceContext);

		m_mRenderContainer[objectid]->SetMesh(m_pDirectionalLightMesh);//mesh set�� ���ÿ� instancing buffer ���� �� se
		m_mRenderContainer[objectid]->SetShader(m_pDirectionalLightShader);
		m_mRenderContainer[objectid]->SetBuffer(m_pDirectionalLightBuffer);

		m_mRenderContainer[objectid]->Begin();
		break;

	case object_id::OBJECT_POINT_LIGHT:
		//point light
		m_mRenderContainer[objectid] = new CRenderContainer(m_pCamera, m_pd3dDevice, m_pd3dDeviceContext);

		m_mRenderContainer[objectid]->SetMesh(m_pPointLightMesh);
		m_mRenderContainer[objectid]->SetShader(m_pPointLightShader);
		m_mRenderContainer[objectid]->SetBuffer(m_pPointLightBuffer);

		m_mRenderContainer[objectid]->Begin();
		break;
	case object_id::OBJECT_SPOT_LIGHT:
		//point light
		m_mRenderContainer[objectid] = new CRenderContainer(m_pCamera, m_pd3dDevice, m_pd3dDeviceContext);

		m_mRenderContainer[objectid]->SetMesh(m_pSpotLightMesh);
		m_mRenderContainer[objectid]->SetShader(m_pSpotLightShader);
		m_mRenderContainer[objectid]->SetBuffer(m_pSpotLightBuffer);

		m_mRenderContainer[objectid]->Begin();
		break;
	case object_id::OBJECT_CAPSULE_LIGHT:
		//point light
		m_mRenderContainer[objectid] = new CRenderContainer(m_pCamera, m_pd3dDevice, m_pd3dDeviceContext);

		m_mRenderContainer[objectid]->SetMesh(m_pCapsuleLightMesh);
		m_mRenderContainer[objectid]->SetShader(m_pCapsuleLightShader);
		m_mRenderContainer[objectid]->SetBuffer(m_pCapsuleLightBuffer);

		m_mRenderContainer[objectid]->Begin();
		break;

	case object_id::OBJECT_POSTPROCESSING:
		//�ڱ� shader set
		m_mRenderContainer[objectid] = new CRenderContainer(m_pCamera, m_pd3dDevice, m_pd3dDeviceContext);

		m_mRenderContainer[objectid]->SetShader(m_pPostProcessingShader);
		m_mRenderContainer[objectid]->SetMesh(m_pPostProcessingMesh);
		m_mRenderContainer[objectid]->Begin();
		break;
	case object_id::OBJECT_SKYBOX:
		m_mRenderContainer[objectid] = new CRenderContainer(m_pCamera, m_pd3dDevice, m_pd3dDeviceContext);

		m_mRenderContainer[objectid]->SetMesh(m_pSkyBoxMesh);
		m_mRenderContainer[objectid]->SetShader(m_pSkyBoxShader);
		m_mRenderContainer[objectid]->SetMaterial(m_pSkyBoxMaterial);
		m_mRenderContainer[objectid]->SetInstanceBuffer(m_pSkyBoxBuffer);
		m_mRenderContainer[objectid]->SetTexture(m_pSkyBoxTexture);

		m_mRenderContainer[objectid]->Begin();
		break;
	}

	return m_mRenderContainer[objectid];
}