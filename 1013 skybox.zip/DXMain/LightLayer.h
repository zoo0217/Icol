#pragma once
#include "Layer.h"
#include "Texture.h"

class CRenderContainerSeller;

class CLightLayer : public CLayer {
public:
	//---------------------------dxobject---------------------------------
	bool Begin(CRenderContainerSeller* pSeller, shared_ptr<CTexture> pRenderTargetTexture);
	virtual bool End();

	virtual void SetShaderState();
	virtual void CleanShaderState();

	virtual void UpdateShaderState();
	//---------------------------dxobject---------------------------------

	//--------------------------container---------------------------------
	virtual void RenderExcute();
	//--------------------------container---------------------------------

private:
	virtual void CreateShaderState();

	//test
	//mapLightRenderContainer m_mLightRenderContainer;
	shared_ptr<CTexture> m_pRenderTargetTexture{ nullptr };
	
	//���� ����� ���� ������ state.
	ID3D11BlendState* m_pLightBlendState{ nullptr };
	ID3D11DepthStencilState* m_pLightDepthStencilState{ nullptr };
	ID3D11RasterizerState* m_pLightRasterizerState{ nullptr };

	//���� ���� ����
	ID3D11BlendState* m_pPreBlendState{ nullptr };
	float* m_pPreBlendFactor{ nullptr };
	UINT m_PreSampleMask{ 0 };
	ID3D11DepthStencilState* m_pPreDepthStencilState{ nullptr };
	UINT m_PreStencilRef{ 0 };
	ID3D11RasterizerState* m_pPreRasterizerState{ nullptr };
public:
	CLightLayer(shared_ptr<CCamera> pCamera, ID3D11Device* pd3dDevice, ID3D11DeviceContext* pd3dDeviceContext);
	virtual ~CLightLayer();

};